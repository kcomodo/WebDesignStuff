var LoginBox = React.createClass({
    render: function () {
        return (
            <div className="LoginBox">
                <h1>Epic Login</h1>
                <LoginForm2 />
            </div>
        );
    }
});
var LoginForm2 = React.createClass({
    getInitialState: function () {
        return {
            useremail: "",
            userpassword: ""
        };
    },
    validateEmail: function (value) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return regex.test(value);
    },
    commonValidate: function () {
        return true;
    },
    setValue: function (field, event) {
        var object = {};
        object[field] = event.target.value;
        this.setState(object)
    },
    render: function () {
        return (
            <form className="loginForm" onSubmit={this.handleSubmit}>
                <table>
                    <tbody>
                        <tr>
                            <th>
                                Email
            )               </th>
                            <td>
                                <TextInput
                                    value={this.state.useremail}
                                    uniqueName="useremail"
                                    textArea={false}
                                    required={true}
                                    validate={this.validateEmail}
                                    onChange={this.setValue.bind(this, 'useremail')}
                                    errorMessage="Invalid E-Mail"
                                    emptyMessage="E-Mail is required" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <TextInput
                                    value={this.state.userpassword}
                                    uniqueName="userpassword"
                                    textArea={false}
                                    required={true}
                                    validate = {this.commonValidate}
                                    onChange={this.setValue}
                                    errorMessage="User password is invalid"
                                    emptyMessage="User password is required"/>
                            </td>
                        </tr>
                    </tbody>
                    </table>
            </form>
        );
    }
});
var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        }
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': this.props.visible
        });
        return (
            <td>{this.props.errorMessage}</td>
        )
    }

});
var textInput = React.createClass({
    getInitialState: function () {
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage = "",
            errorVisible: false
        };
    },
    handleChange: function (event) {
        this.validation(event.target.value);
        if (this.props.OnChange) {
            this.props.onChange(event);
        }
    },
    validation: function (value, valid) {
        if (typeof valid === 'undefined') {
            valid = true;
        }
        var message = "";
        var errorVisible = false;
        if (!valid) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;

        }
        else if (value.length < this.props.minCharacters) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message;
            errorVisible: errorVisible
        });
    },
    handleBlur: function (event) {
        var valid = this.props.validation(event.target.value);
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textArea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        valid={this.props.value} />
                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        valid={this.props.value} />
                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );

        }
    }
});
ReactDOM.render(
    <LoginBox />,
    document.getElementById('content')
);