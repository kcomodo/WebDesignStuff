/**
 * This file is based on Facebook's version of server.js, included in the
 * download for this tutorial: https://facebook.github.io/react/docs/tutorial.html
 */

var fs = require('fs');
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();


const mysql = require('mysql2');
const con = mysql.createConnection({
    host: "istwebclass.org",
    user: "qho_user1",
    password:"Rzkkpur2",
    database: "qho_capstonewebsite"
});
/*
con.connect(function (err) {

    if (err) throw (err);
    console.log("Connected");
});
*/
app.set('port', (process.env.PORT || 3000));

app.use('/', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.get('/api/donations', function(req, res) {
  fs.readFile(DONATIONS_FILE, function(err, data) {
    if (err) {
      console.error(err);
      process.exit(1);
    }
    res.setHeader('Cache-Control', 'no-cache');
    res.json(JSON.parse(data));
  });
});

app.post('/api/donations', function(req, res) {
  fs.readFile(DONATIONS_FILE, function(err, data) {
    if (err) {
      console.error(err);
      process.exit(1);
    }
    var donations = JSON.parse(data);
    // NOTE: In a real implementation, we would likely rely on a database or
    // some other approach (e.g. UUIDs) to ensure a globally unique id. We'll
    // treat Date.now() as unique-enough for our purposes.
    var newDonation = {
      id: Date.now(),
      contributor: req.body.contributor,
      amount: req.body.amount,
      comment: req.body.comment
    };
    donations.push(newDonation);
    fs.writeFile(DONATIONS_FILE, JSON.stringify(donations, null, 4), function(err) {
      if (err) {
        console.error(err);
        process.exit(1);
      }
      res.setHeader('Cache-Control', 'no-cache');
      res.json(donations);
    });
  });
});

/*
app.post('/product', function (req, res) {
    var pname = req.body.productName;
    var pqty = req.body.productQty;
    var pdescr = req.body.productDescr;

    console.log(pname);
    console.log(pqty);
    console.log(pdescr);

    var sqlins = "INSERT INTO theproducts(productName, productQty, productDescr) " + 
    " VALUES (?, ?, ?)";

    var inserts = [pname, pqty, pdescr]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertproducts.html');
        res.end();
    });

});
app.post('/employee', function (req, res) {
  
    var ename = req.body.employeeName;
    var eemail = req.body.employeeEmail;
    var ephone = req.body.employeePhone;
    var esalary = req.body.employeeSalary;

    console.log(ename);
    console.log(eemail);
    console.log(ephone);
    console.log(esalary);

    var sqlins = "INSERT INTO employeetable(dbemployeename, dbemployeeemail, dbemployeephone, dbemployeesalary) " +
        " VALUES (?, ?, ?, ?)";

    var inserts = [ename, eemail, ephone, esalary]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertemployees.html');
        res.end();
    });

});
*/
app.listen(app.get('port'), function() {
  console.log('Server started: http://localhost:' + app.get('port') + '/');
});
