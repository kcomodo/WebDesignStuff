var EmployeeBox = React.createClass({
    getInitialState: function () {
        //this will hold all the data being read and posted to the file
        return { data: [] };
    },
    loadEmployeesFromServer: function () {
        $.ajax({
            url: '/getemp',
            data: { 'employeeid': employeeid.value },
            dataType: 'json',
            cache: false,
            success: function (data) {
                //set the state with the newly loaded data so the display will update
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        //Once the component is fully loaded, we grab the donations
        this.loadEmployeesFromServer();
        //... and set an interval to continuously load new data:
        setInterval(this.loadloadEmployeesFromServer, this.props.pollInterval);
    },

    render: function () {
        return (
            <div>
                <h1>Employees</h1>
                <Employeeform2 onEmployeeSubmit={this.loadEmployeesFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Key</th>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Salary</th>
                            </tr>
                         </thead>
                        <EmployeeList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            employeeid: "",
            employeename: "",
            employeeemail: "",
            employeephone: "",
            employeesalary: ""
        };
    },

    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the default behavior
        e.preventDefault();

        var employeeid = this.state.employeeid.trim();
        var employeeemail = this.state.employeeemail.trim();
        var employeename = this.state.employeename.trim();
        var employeephone = this.state.employeephone.trim();
        var employeesalary = this.state.employeesalary;

        this.props.onEmployeeSubmit({ employeeid: employeeid, employeename: employeename, employeeemail: employeeemail, employeephone, employeephone, employeesalary, employeesalary });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Employees</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Employee ID</th>
                            <td>
                                <input type="text" name="employeeid" id="employeeid" value={this.state.employeeid} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Name</th>
                            <td>
                                <input name="employeename" id="employeename" value={this.state.employeename} />
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Email</th>
                            <td>
                                <input name="employeeemail" id="employeeemail" value={this.state.employeeemail} />
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Phone</th>
                            <td>
                                <input name="employeephone" id="employeephone" value={this.state.employeephone} />
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Salary</th>
                            <td>
                                <input name="employeesalary" id="employeesalary" value={this.state.employeesalary} />
                            </td>
                        </tr>    
                    </tbody>
                </table>
                <input type="submit" value="Search Employee" />

            </form>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var employeeNodes = this.props.data.map(function (employee) {
            //map the data to individual donations
            return (
                <Employee
                    key={employee.dbemployeekey}
                    empkey={employee.dbemployeekey}
                    empid={employee.dbemployeeid}
                    empname={employee.dbemployeename}
                    empemail={employee.dbemployeeemail}
                    empphone={employee.dbemployeephone}
                    empsalary={employee.dbemployeesalary}
                >
                </Employee>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
                            <td>
                                {this.props.empkey} 
                            </td>
                            <td>
                                {this.props.empid}
                            </td>
                            <td>
                                {this.props.empname}
                            </td>
                            <td>
                                {this.props.empemail}
                            </td>
                            <td>
                                {this.props.empphone}
                            </td>
                            <td>
                                {this.props.empsalary}
                            </td>
                </tr>
        );
    }
});


ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);

