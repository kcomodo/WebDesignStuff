var EmployeeBox = React.createClass({
    getInitialState: function () {
        //this will hold all the data being read and posted to the file
        return { data: [] };
    },
    loadEmployeesFromServer: function () {
        $.ajax({
            url: '/getemp',
            data: { 'employeesid': employeesid.value },
            dataType: 'json',
            cache: false,
            success: function (data) {
                //set the state with the newly loaded data so the display will update
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        //Once the component is fully loaded, we grab the donations
        this.loadEmployeesFromServer();
        //... and set an interval to continuously load new data:
        setInterval(this.loadloadEmployeesFromServer, this.props.pollInterval);
    },

    render: function () {
        return (
            <div>
                <h1>Employees Info</h1>
                <Employeeform2 onEmployeeSubmit={this.loadEmployeesFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Key</th>
                                <th>Last Name</th>
                                <th>First Name</th>
                                <th>Hire Date</th>
                            </tr>
                         </thead>
                        <EmployeeList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            employeesid: "",
            employeesHireDate: "",
            employeesFirstName: "",
            employeesLastName: ""
        };
    },

    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the default behavior
        e.preventDefault();

        var employeesid = this.state.employeesid;
        var employeesHireDate = this.state.employeesHireDate;
        var employeesLastName = this.state.employeesLastName;
        var employeesFirstName = this.state.employeesFirstName;

        this.props.onEmployeeSubmit({
            employeesid: employeesid, employeesHireDate: employeesHireDate, employeesLastName: employeesLastName, employeesFirstName: employeesFirstName
        });


    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Employees</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Employee ID</th>
                            <td>
                                <input type="text" name="employeesid" id="employeesid" value={this.state.employeesid} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Hire Date</th>
                            <td>
                                <input name="employeesHireDate" id="employeesHireDate" value={this.state.employeesHireDate} onChange={this.handleChange} />
                            </td>
                        </tr> 
                        <tr>
                            <th>Employee First Name</th>
                            <td>
                                <input name="employeesFirstName" id="employeesFirstName" value={this.state.employeesFirstName} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Last Name</th>
                            <td>
                                <input name="employeesLastName" id="employeesLastName" value={this.state.employeesLastName} onChange={this.handleChange} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <input type="submit" value="Search Employee" />

            </form>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var employeeNodes = this.props.data.map(function (employees) {
            //map the data to individual donations
            return (
                <Employee
                    ekey={employees.employeesid}
                    eHireDate={employees.employeesHireDate}
                    eFirstName={employees.employeesFirstName}
                    eLastName={employees.employeesLastName}
             
                >
                </Employee>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
                            <td>
                                {this.props.ekey} 
                            </td>
                            <td>
                                {this.props.eHireDate}
                            </td>
                            <td>
                                {this.props.empFirstName}
                            </td>
                            <td>
                                {this.props.eLastName}
                            </td>

                </tr>
        );
    }
});


ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);

