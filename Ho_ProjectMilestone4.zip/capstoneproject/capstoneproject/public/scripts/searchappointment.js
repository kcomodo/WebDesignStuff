var EmployeeBox = React.createClass({
    getInitialState: function () {
        //this will hold all the data being read and posted to the file
        return { data: [] };
    },
    loadEmployeesFromServer: function () {
        $.ajax({
            url: '/getapp',
            data: { 'appointmentid': appointmentid.value },
            dataType: 'json',
            cache: false,
            success: function (data) {
                //set the state with the newly loaded data so the display will update
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        //Once the component is fully loaded, we grab the donations
        this.loadEmployeesFromServer();
        //... and set an interval to continuously load new data:
        setInterval(this.loadloadEmployeesFromServer, this.props.pollInterval);
    },

    render: function () {
        return (
            <div>
                <h1>Appointment Info</h1>
                <Employeeform2 onEmployeeSubmit={this.loadEmployeesFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Appointment ID</th>
                                <th>Customer ID</th>
                                <th>Installer ID</th>
                                <th>Employees ID</th>
                            </tr>
                         </thead>
                        <EmployeeList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            appointmentid: "",
            customerid: "",
            installerid: "",
            employeesid: ""
        };
    },

    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the default behavior
        e.preventDefault();

        var appointmentid = this.state.appointmentid;
        var customerid = this.state.customerid;
        var installerid = this.state.installerid;
        var employeesid = this.state.employeesid;
        this.props.onFacultySubmit({
            appointmentid: appointmentid, customerid: customerid, installerid: installerid, employeesid: employeesid
        });


    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Employees</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Appointment ID</th>
                            <td>
                                <input type="text" name="appointmentid" id="appointmentid" value={this.state.appointmentid} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer ID</th>
                            <td>
                                <input name="customerid" id="customerid" value={this.state.customerid} onChange={this.handleChange} />
                            </td>
                        </tr> 
                        <tr>
                            <th>Installer ID</th>
                            <td>
                                <input name="installerid" id="installerid" value={this.state.installerid} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Last Name</th>
                            <td>
                                <input name="employeesid" id="employeesid" value={this.state.employeesid} onChange={this.handleChange} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <input type="submit" value="Search Appointment" />

            </form>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var employeeNodes = this.props.data.map(function (appointment) {
            //map the data to individual donations
            return (
                <Employee
                    aid={appointment.appointmentid}
                    aCustomer={appointment.customerid}
                    aInstaller={appointment.installerid}
                    aEmployee={appointment.employeesid}
             
                >
                </Employee>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
                            <td>
                                {this.props.aid} 
                            </td>
                            <td>
                                {this.props.aCustomer}
                            </td>
                            <td>
                                {this.props.aInstaller}
                            </td>
                            <td>
                                {this.props.aEmployee}
                            </td>

                </tr>
        );
    }
});


ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);

