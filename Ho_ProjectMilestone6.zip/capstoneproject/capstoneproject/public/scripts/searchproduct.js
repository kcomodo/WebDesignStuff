var EmployeeBox = React.createClass({
    getInitialState: function () {
        //this will hold all the data being read and posted to the file
        return { data: [] };
    },
    loadEmployeesFromServer: function () {
        $.ajax({
            url: '/getprod',
            data: { 'productid': productid.value },
            dataType: 'json',
            cache: false,
            success: function (data) {
                //set the state with the newly loaded data so the display will update
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        //Once the component is fully loaded, we grab the donations
        this.loadEmployeesFromServer();
        //... and set an interval to continuously load new data:
        setInterval(this.loadloadEmployeesFromServer, this.props.pollInterval);
    },

    render: function () {
        return (
            <div>
                <h1>Product Info</h1>
                <Employeeform2 onEmployeeSubmit={this.loadEmployeesFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                            <th>Product Size</th>
                            <th>Product Amount</th>
                            </tr>
                         </thead>
                        <EmployeeList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            productid: "",
            productName: "",
            productPrice: "",
            productSize: "",
            productAmount: ""
        };
    },

    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the default behavior
        e.preventDefault();

        var productid = this.state.productid;
        var productName = this.state.productName;
        var productPrice = this.state.productPrice;
        var productSize = this.state.productSize;
        var productAmount = this.state.productAmount;

        this.props.onFacultySubmit({
            productid: productid, productName: productName, productPrice: productPrice, productSize: productSize, productAmount: productAmount
        });


    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Product</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Product ID</th>
                            <td>
                                <input type="text" name="productid" id="productid" value={this.state.productid} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Product Name</th>
                            <td>
                                <input name="productName" id="productName" value={this.state.productName} onChange={this.handleChange} />
                            </td>
                        </tr> 
                        <tr>
                            <th>Product Price</th>
                            <td>
                                <input name="productSize" id="productSize" value={this.state.productSize} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Product Size</th>
                            <td>
                                <input name="productPrice" id="productPrice" value={this.state.productPrice} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Product Amount</th>
                            <td>
                                <input name="productAmount" id="productAmount" value={this.state.productAmount} onChange={this.handleChange} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <input type="submit" value="Search Product" />

            </form>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var employeeNodes = this.props.data.map(function (product) {
            //map the data to individual donations
            return (
                <Employee
                    pid={product.productid}
                    pName={product.productName}
                    pSize={product.productSize}
                    pPrice={product.productPrice}
                    pAmount={product.productAmount}
             
                >
                </Employee>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
                            <td>
                                {this.props.pid} 
                            </td>
                            <td>
                                {this.props.pName}
                            </td>
                            <td>
                                {this.props.pSize}
                            </td>
                            <td>
                                {this.props.pPrice}
                            </td>
                            <td>
                                {this.props.pAmount}
                            </td>


                </tr>
        );
    }
});


ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);

