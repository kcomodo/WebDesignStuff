var EmployeeBox = React.createClass({
    getInitialState: function () {
        return {
            data: []            
        };
    },
    loadEmployeesFromServer: function () {
        var emailervalue = 2
        if (empmaileryes.checked) {
            emailervalue = 1;
        }
        if (empmailerno.checked) {
            emailervalue = 0;
        }

        $.ajax({
            url: '/getcust',
            data: {
                'customerid': customerid.value,
                'customerFirstName': customerFirstName.value,
                'customerLastName': customerLastName.value,
                'customerAddress1': customerAddress1.value,
                'customerAddress2': customerAddress2.value,
                'customerCity': customerCity.value,
                'customerState': customerState.value,
                'customerZip': customerZip.value,
                'customerPhoneNumber': customerPhoneNumber.value
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleEmpFromServer: function (employee) {
        
        $.ajax({
            url: '/updatesinglecus',
            dataType: 'json',
            data: employee,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadEmployeesFromServer();
    },

    render: function () {
        return (
            <div>
                <h1>Search Customer</h1>
                <Employeeform2 onEmployeeSubmit={this.loadEmployeesFromServer} />
                <br />
                <div id = "theresults">
                    <div id = "theleft">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                    <th>Address 1</th>
                                    <th>Address 2</th>
                                    <th>City</th>
                                    <th>State</th>
                                    <th>Zip</th>
                                    <th>Phone Number</th>
                                <th></th>
                            </tr>
                        </thead>
                        <EmployeeList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <EmployeeUpdateform onUpdateSubmit={this.updateSingleEmpFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            customerid: "",
            customerFirstName: "",
            customerLastName: "",
            customerAddress1: "",
            customerAddress2: "",
            customerCity: "",
            customerState: "",
            customerZip: "",
            customerPhoneNumber: "",
            data: []
        };
    },
    handleOptionChange: function (e) {
        this.setState({
            selectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleSubmit: function (e) {
        e.preventDefault();

        var customerid = this.state.customerid;
        var customerFirstName = this.state.customerFirstName;
        var customerLastName = this.state.customerLastName;
        var customerAddress1 = this.state.customerAddress1;
        var customerAddress2 = this.state.customerAddress2;
        var customerCity = this.state.customerCity;
        var customerState = this.state.customerState;
        var customerZip = this.state.customerZip;
        var customerPhoneNumber = this.state.customerPhoneNumber;


        this.props.onEmployeeSubmit({
            customerid: customerid, customerFirstName: customerFirstName, customerLastName: customerLastName, customerAddress1: customerAddress1, customerAddress2: customerAddress2, customerCity: customerCity,
            customerState: customerState, customerZip: customerZip, customerPhoneNumber: customerPhoneNumber
        });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id = "theform">
                    <form onSubmit={this.handleSubmit}>
                
                        <table>
                            <tbody>
                                <tr>
                                    <th>Customer ID</th>
                                    <td>
                                        <input type="text" name="customerid" id="customerid" value={this.state.customerid} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer First Name</th>
                                    <td>
                                        <input name="customerFirstName" id="customerFirstName" value={this.state.customerFirstName} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Last Name</th>
                                    <td>
                                        <input name="customerLastName" id="customerLastName" value={this.state.customerLastName} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Address</th>
                                    <td>
                                        <input name="customerAddress1" id="customerAddress1" value={this.state.customerAddress1} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Address 2</th>
                                    <td>
                                        <input name="customerAddress2" id="customerAddress2" value={this.state.customerAddress2} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer City</th>
                                    <td>
                                        <input name="customerCity" id="customerCity" value={this.state.customerCity} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer State</th>
                                    <td>
                                        <input name="customerState" id="customerState" value={this.state.customerState} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Zip</th>
                                    <td>
                                        <input name="customerZip" id="customerZip" value={this.state.customerZip} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Phone Number</th>
                                    <td>
                                        <input name="customerPhoneNumber" id="customerPhoneNumber" value={this.state.customerPhoneNumber} onChange={this.handleChange} />
                                    </td>
                                </tr>
 
                            </tbody>
                        </table><br/>
                        <input type="submit" value="Search Employee" />
                     </form>
                </div>
                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Clear Form" />
                    </form>
                </div>
        </div>
        );
    }
});

var EmployeeUpdateform = React.createClass({
    getInitialState: function () {
        return {
   
            upcustomerid: "",
            upcustomerFirstName: "",
            upcustomerLastName: "",
            upcustomerAddress1: "",
            upcustomerAddress2: "",
            upcustomerCity: "",
            upcustomerState: "",
            upcustomerZip: "",
            upcustomerPhoneNumber: "",

            updata: []
        };
    },
    handleUpOptionChange: function (e) {
        this.setState({
            upselectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ updata: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleUpSubmit: function (e) {
        e.preventDefault();

        var upcustomerid = this.state.upcustomerid;
        var upcustomerFirstName = this.state.upcustomerFirstName;
        var upcustomerLastName = this.state.upcustomerLastName;
        var upcustomerAddress1 = this.state.upcustomerAddress1;
        var upcustomerAddress2 = this.state.upcustomerAddress2;
        var upcustomerCity = this.state.upcustomerCity;
        var upcustomerState = this.state.upcustomerState;
        var upcustomerZip = this.state.upcustomerZip;
        var upcustomerPhoneNumber = this.state.upcustomerPhoneNumber;


        this.props.onUpdateSubmit({
            upcustomerid: upcustomerid, upcustomerFirstName: upcustomerFirstName, upcustomerLastName: upcustomerLastName, upcustomerAddress1: upcustomerAddress1, upcustomerAddress2: upcustomerAddress2, upcustomerCity: upcustomerCity,
            upcustomerState: upcustomerState, upcustomerZip: upcustomerZip, upcustomerPhoneNumber: upcustomerPhoneNumber
        });


    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id="theform">
                    <form onSubmit={this.handleUpSubmit}>

                        <table>
                            <tbody>
                                <tr>
                                    <th>Customer ID</th>
                                    <td>
                                        <input type="text" name="upcustomerid" id="upcustomerid" value={this.state.upcustomerid} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer First Name</th>
                                    <td>
                                        <input name="upcustomerFirstName" id="upcustomerFirstName" value={this.state.upcustomerFirstName} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Last Name</th>
                                    <td>
                                        <input name="upcustomerLastName" id="upcustomerFirstName" value={this.state.upcustomerLastName} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Address 1</th>
                                    <td>
                                        <input name="upcustomerAddress1" id="upcustomerAddress1" value={this.state.upcustomerAddress1} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Address 2</th>
                                    <td>
                                        <input name="upcustomerAddress2" id="upcustomerAddress2" value={this.state.upcustomerAddress2} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer City</th>
                                    <td>
                                        <input name="upcustomerCity" id="upcustomerCity" value={this.state.upcustomerCity} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer State</th>
                                    <td>
                                        <input name="upcustomerState" id="upcustomerState" value={this.state.upcustomerState} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Zip</th>
                                    <td>
                                        <input name="upcustomerZip" id="upcustomerZip" value={this.state.upcustomerZip} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Phone Number</th>
                                    <td>
                                        <input name="upcustomerPhoneNumber" id="upcustomerPhoneNumber" value={this.state.upcustomerPhoneNumber} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                            </tbody>
                        </table><br />
                        <input type="hidden" name="upcustomerid" id="upcustomerid" onChange={this.handleUpChange} />
                        <input type="submit" value="Update Customer" />
                    </form>
                </div>
            </div>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var employeeNodes = this.props.data.map(function (customers) {
            return (
                <Employee

                    custid={customers.customerid}
                    custFirstname={customers.customerFirstName}
                    custLastName={customers.customerLastName}
                    custAddress1={customers.customerAddress1}
                    custAddress2={customers.customerAddress2}
                    custCity={customers.customerCity}
                    custState={customers.customerState}
                    custZip={customers.customerZip}
                    custPhoneNumber={customers.custp}
                >
                </Employee>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({
    getInitialState: function () {
        return {
            upcustomerid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupempkey = this.props.empkey;
        
        this.loadSingleEmp(theupempkey);
    },
    loadSingleEmp: function (theupempkey) {
        $.ajax({
            url: '/getsinglecust',
            data: {
                'upempkey': theupempkey
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (employees) {
                    upcustomerid.value = customers.customerid;
                    upcustomerFirstName.value = customers.customerFirstName;
                    upcustomerLastName.value = customers.customerLastName;
                    upcustomerAddress1.value = customers.customerAddress1;
                    upcustomerAddress2.value = customers.customerAddress2;
                    upcustomerCity.value = customers.customerCity;
                    upcustomerState.value = customers.customerState;
                    upcustomerZip.value = customers.customerZip;
                    upcustomerPhoneNumber.value = customers.customerPhoneNumber;




                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        
    },

    render: function () {
        
        
 
        
        return (
            
            <tr>
                            <td>
                                {this.props.custid}
                            </td>
                            <td>
                                {this.props.custFirstname}
                            </td>
                            <td>
                                {this.props.custLastName}
                            </td>
                            <td>
                                {this.props.custAddress1}
                </td>
                <td>
                    {this.props.custAddress2}
                </td>
                <td>
                    {this.props.custCity}
                </td>
                <td>
                    {this.props.custState}
                </td>
                <td>
                    {this.props.custZip}
                </td>
                <td>
                    {this.props.custPhoneNumber}
                </td>
                            <td>
                            <form onSubmit={this.updateRecord}>
                                     
                                    <input type="submit" value="Update Record" />
                                </form>
                            </td>
                </tr>
        );
    }
});

var SelectList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="emptype" id="emptype">
                <option value = "0"></option>
                {optionNodes}
            </select>
        );
    }
});

var SelectUpdateList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="upemptype" id="upemptype">
                <option value="0"></option>
                {optionNodes}
            </select>
        );
    }
});


ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);

