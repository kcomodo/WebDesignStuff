var EmployeeBox = React.createClass({
    getInitialState: function () {
        return {
            data: []            
        };
    },
    loadEmployeesFromServer: function () {
        var emailervalue = 2
        if (empmaileryes.checked) {
            emailervalue = 1;
        }
        if (empmailerno.checked) {
            emailervalue = 0;
        }

        $.ajax({
            url: '/getapp',
            data: {
                'appointmentid': appointmentid.value,
                'customerid': customerid.value,
                'installerid': installerid.value,
                'employeesid': employeesid.value
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleEmpFromServer: function (employee) {
        
        $.ajax({
            url: '/updatesingleappointment',
            dataType: 'json',
            data: employee,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadEmployeesFromServer();
    },

    render: function () {
        return (
            <div>
                <h1>Search Appointment</h1>
                <Employeeform2 onEmployeeSubmit={this.loadEmployeesFromServer} />
                <br />
                <div id = "theresults">
                    <div id = "theleft">
                    <table>
                        <thead>
                            <tr>
                                <th>Appointment ID</th>
                                <th>Customer ID</th>
                                <th>Installer ID</th>
                                <th>Employee ID</th>
                                <th></th>
                            </tr>
                        </thead>
                        <EmployeeList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <EmployeeUpdateform onUpdateSubmit={this.updateSingleEmpFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            appointmentid: "",
            customerid: "",
            installerid: "",
            employeesid: "",
            data: []
        };
    },
    handleOptionChange: function (e) {
        this.setState({
            selectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleSubmit: function (e) {
        e.preventDefault();

        var appointmentid = this.state.appointmentid;
        var customerid = this.state.customerid;
        var installerid = this.state.installerid;
        var employeesid = this.state.employeesid;


        this.props.onEmployeeSubmit({
            appointmentid: appointmentid, customerid: customerid, installerid: installerid, employeesid: employeesid
   
        });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id = "theform">
                    <form onSubmit={this.handleSubmit}>
                
                        <table>
                            <tbody>
                                <tr>
                                    <th>Appointment ID</th>
                                    <td>
                                        <input type="text" name="appointmentid" id="appointmentid" value={this.state.appointmentid} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer ID</th>
                                    <td>
                                        <input name="customerid" id="customerid" value={this.state.customerid} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Installer ID</th>
                                    <td>
                                        <input name="installerid" id="installerid" value={this.state.installerid} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee Last Name</th>
                                    <td>
                                        <input name="employeesid" id="employeesid" value={this.state.employeesid} onChange={this.handleChange} />
                                    </td>
                                </tr>
 
                            </tbody>
                        </table><br/>
                        <input type="submit" value="Search Appointment" />
                     </form>
                </div>
                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Clear Form" />
                    </form>
                </div>
        </div>
        );
    }
});

var EmployeeUpdateform = React.createClass({
    getInitialState: function () {
        return {
   
            upappointmentid: "",
            upcustomerid: "",
            upinstallerid: "",
            upemployeesid: "",

            updata: []
        };
    },
    handleUpOptionChange: function (e) {
        this.setState({
            upselectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ updata: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleUpSubmit: function (e) {
        e.preventDefault();

        var upappointmentid = this.state.upappointmentid;
        var upcustomerid = this.state.upcustomerid;
        var upinstallerid = this.state.upinstallerid;
        var upemployeesid = this.state.upemployeesid;


        this.props.onUpdateSubmit({

            upappointmentid: upappointmentid, upcustomerid: upcustomerid, upinstallerid: upinstallerid, upemployeesid: upemployeesid
        });


    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id="theform">
                    <form onSubmit={this.handleUpSubmit}>

                        <table>
                            <tbody>
                                <tr>
                                    <th>Appointment ID</th>
                                    <td>
                                        <input type="text" name="upappointmentid" id="upappointmentid" value={this.state.upappointmentid} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer ID</th>
                                    <td>
                                        <input name="upcustomerid" id="upcustomerid" value={this.state.upcustomerid} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Installer ID</th>
                                    <td>
                                        <input name="upinstallerid" id="upinstallerid" value={this.state.upinstallerid} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee ID</th>
                                    <td>
                                        <input name="upemployeesid" id="upemployeesid" value={this.state.upemployeesid} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                            </tbody>
                        </table><br />
                        <input type="hidden" name="upappointmentid" id="upappointmentid" onChange={this.handleUpChange} />
                        <input type="submit" value="Update Appointment" />
                    </form>
                </div>
            </div>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var employeeNodes = this.props.data.map(function (appointment) {
            return (
                <Employee

                    appid={appointment.appointmentid}
                    custid={appointment.customerid}
                    instid={appointment.installerid}
                    empid={appointment.employeesid}
                >
                </Employee>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({
    getInitialState: function () {
        return {
            upappointmentid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupempkey = this.props.empkey;
        
        this.loadSingleEmp(theupempkey);
    },
    loadSingleEmp: function (theupempkey) {
        $.ajax({
            url: '/getsingleappointment',
            data: {
                'upempkey': theupempkey
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (appointment) {
                    upappointmentid.value = appointment.appointmentid;
                    upcustomerid.value = appointment.customerid;
                    upinstallerid.value = appointment.installerid;
                    upemployeesid.value = appointment.employeesid;


                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        
    },

    render: function () {
        
        
 
        
        return (
            
            <tr>
                            <td>
                                {this.props.appid}
                            </td>
                            <td>
                                {this.props.custid}
                            </td>
                            <td>
                                {this.props.instid}
                            </td>
                            <td>
                                {this.props.empid}
                            </td>
                            <td>
                            <form onSubmit={this.updateRecord}>
                                     
                                    <input type="submit" value="Update Record" />
                                </form>
                            </td>
                </tr>
        );
    }
});

var SelectList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="emptype" id="emptype">
                <option value = "0"></option>
                {optionNodes}
            </select>
        );
    }
});

var SelectUpdateList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="upemptype" id="upemptype">
                <option value="0"></option>
                {optionNodes}
            </select>
        );
    }
});


ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);

