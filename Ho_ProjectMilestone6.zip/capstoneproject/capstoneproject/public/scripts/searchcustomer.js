var EmployeeBox = React.createClass({
    getInitialState: function () {
        //this will hold all the data being read and posted to the file
        return { data: [] };
    },
    loadEmployeesFromServer: function () {
        $.ajax({
            url: '/getcust',
            data: { 'customerid': customerid.value },
            dataType: 'json',
            cache: false,
            success: function (data) {
                //set the state with the newly loaded data so the display will update
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        //Once the component is fully loaded, we grab the donations
        this.loadEmployeesFromServer();
        //... and set an interval to continuously load new data:
        setInterval(this.loadloadEmployeesFromServer, this.props.pollInterval);
    },

    render: function () {
        return (
            <div>
                <h1>Customer Info</h1>
                <Employeeform2 onEmployeeSubmit={this.loadEmployeesFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Customer ID</th>
                                <th>Customer First Name</th>
                                <th>Customer Last Name</th>
                                <th>Customer Address</th>
                                <th>Customer Address 2</th>
                                <th>Customer City</th>
                                <th>Customer State</th>
                                <th>Customer Zip</th>
                                <th>Customer Phone Number</th>
                            </tr>
                         </thead>
                        <EmployeeList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            customerid: "",
            customerFirstName: "",
            customerLastName: "",
            customerAddress1: "",
            customerAddress2: "",
            customerCity: "",
            customerState: "",
            customerZip: "",
            customerPhoneNumber: ""
        };
    },

    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the default behavior
        e.preventDefault();

        var customerid = this.state.customerid;
        var customerFirstName = this.state.customerFirstName;
        var customerLastName = this.state.customerLastName;
        var customerAddress1 = this.state.customerAddress1;
        var customerAddress2 = this.state.customerAddress2;
        var customerCity = this.state.customerCity;
        var customerState = this.state.customerState;
        var customerZip = this.state.customerZip;
        var customerPhoneNumber = this.state.customerPhoneNumber;

        this.props.onFacultySubmit({
            customerid: customerid, customerFirstName: customerFirstName, customerLastName: customerLastName, customerAddress1: customerAddress1, customerAddress2: customerAddress2, customerCity: customerCity,
            customerState: customerState, customerZip: customerZip, customerPhoneNumber: customerPhoneNumber
        });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Customer</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Customer ID</th>
                            <td>
                                <input type="text" name="customerid" id="customerid" value={this.state.customerid} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer First Name</th>
                            <td>
                                <input name="customerFirstName" id="customerFirstName" value={this.state.customerFirstName} onChange={this.handleChange} />
                            </td>
                        </tr> 
                        <tr>
                            <th>Customer Last Name</th>
                            <td>
                                <input name="customerLastName" id="customerLastName" value={this.state.customerLastName} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Customer Address</th>
                            <td>
                                <input name="customerAddress1" id="customerAddress1" value={this.state.customerAddress1} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer Address 2</th>
                            <td>
                                <input name="customerAddress2" id="customerAddress2" value={this.state.customerAddress2} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer City</th>
                            <td>
                                <input name="customerCity" id="customerCity" value={this.state.customerCity} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer State</th>
                            <td>
                                <input name="customerState" id="customerState" value={this.state.customerState} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer Zip</th>
                            <td>
                                <input name="customerZip" id="customerZip" value={this.state.customerZip} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer Phone Number</th>
                            <td>
                                <input name="customerPhoneNumber" id="customerPhoneNumber" value={this.state.customerPhoneNumber} onChange={this.handleChange} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <input type="submit" value="Search Customer" />

            </form>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var employeeNodes = this.props.data.map(function (customer) {
            //map the data to individual donations
            return (
                <Employee
                    cid={customer.customerid}
                    cFirstName={customer.customerFirstName}
                    cLastName={customer.customerLastName}
                    cAddress1={customer.customerAddress1}
                    cAddress2={customer.customerAddress2}
                    cCity={customer.customerCity}
                    cState={customer.customerState}
                    cZip={customer.customerZip}
                    cPhoneNumber={customer.customerPhoneNumber}





             
                >
                </Employee>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
                            <td>
                                {this.props.cid} 
                            </td>
                            <td>
                                {this.props.cFirstName}
                            </td>
                            <td>
                                {this.props.cLastName}
                            </td>
                            <td>
                                {this.props.cAddress1}
                            </td>
                            <td>
                                {this.props.cAddress2}
                            </td>
                            <td>
                                {this.props.cCity}
                            </td>
                            <td>
                                {this.props.cState}
                            </td>
                            <td>
                                {this.props.cZip}
                            </td>
                            <td>
                                {this.props.cPhoneNumber}
                            </td>

                </tr>
        );
    }
});


ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);

