var EmployeeBox = React.createClass({
    getInitialState: function () {
        return {
            data: []            
        };
    },
    loadEmployeesFromServer: function () {
        var emailervalue = 2
        if (empmaileryes.checked) {
            emailervalue = 1;
        }
        if (empmailerno.checked) {
            emailervalue = 0;
        }

        $.ajax({
            url: '/getprod',
            data: {
                'productid': productid.value,
                'productName': productName.value,
                'productPrice': productPrice.value,
                'productSize': productSize.value,
                'productAmount': productAmount.value,

            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleEmpFromServer: function (employee) {
        
        $.ajax({
            url: '/updatesingleproduct',
            dataType: 'json',
            data: employee,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadEmployeesFromServer();
    },

    render: function () {
        return (
            <div>
                <h1>Search Product</h1>
                <Employeeform2 onEmployeeSubmit={this.loadEmployeesFromServer} />
                <br />
                <div id = "theresults">
                    <div id = "theleft">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Price</th>
                                    <th>Size</th>
                                    <th>Amount</th>
                                <th></th>
                            </tr>
                        </thead>
                        <EmployeeList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <EmployeeUpdateform onUpdateSubmit={this.updateSingleEmpFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            productid: "",
            productName: "",
            productPrice: "",
            productSize: "",
            productAmount: "",
            data: []
        };
    },
    handleOptionChange: function (e) {
        this.setState({
            selectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleSubmit: function (e) {
        e.preventDefault();
        var productid = this.state.productid;
        var productName = this.state.productName;
        var productPrice = this.state.productPrice;
        var productSize = this.state.productSize;
        var productAmount = this.state.productAmount;


        this.props.onEmployeeSubmit({
            productid: productid, productName: productName, productPrice: productPrice, productSize: productSize, productAmount: productAmount
   
        });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id = "theform">
                    <form onSubmit={this.handleSubmit}>
                
                        <table>
                            <tbody>
                                <tr>
                                    <th>Product ID</th>
                                    <td>
                                        <input type="text" name="productid" id="productid" value={this.state.productid} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Product Name</th>
                                    <td>
                                        <input name="productName" id="productName" value={this.state.productName} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Product Price</th>
                                    <td>
                                        <input name="productSize" id="productSize" value={this.state.productSize} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Product Size</th>
                                    <td>
                                        <input name="productPrice" id="productPrice" value={this.state.productPrice} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Product Amount</th>
                                    <td>
                                        <input name="productAmount" id="productAmount" value={this.state.productAmount} onChange={this.handleChange} />
                                    </td>
                                </tr>
 
                            </tbody>
                        </table><br/>
                        <input type="submit" value="Search Product" />
                     </form>
                </div>
                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Clear Form" />
                    </form>
                </div>
        </div>
        );
    }
});

var EmployeeUpdateform = React.createClass({
    getInitialState: function () {
        return {
   
            upproductid: "",
            upproductName: "",
            upproductPrice: "",
            upproductSize: "",
            upproductAmount: "",

            updata: []
        };
    },
    handleUpOptionChange: function (e) {
        this.setState({
            upselectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ updata: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleUpSubmit: function (e) {
        e.preventDefault();


        var upproductid = this.state.upproductid;
        var upproductName = this.state.upproductName;
        var upproductPrice = this.state.upproductPrice;
        var upproductSize = this.state.upproductSize;
        var upproductAmount = this.state.upproductAmount;


        this.props.onUpdateSubmit({

            upproductid: upproductid, upproductName: upproductName, upproductPrice: upproductPrice, upproductSize: upproductSize, upproductAmount: upproductAmount
        });


    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id="theform">
                    <form onSubmit={this.handleUpSubmit}>

                        <table>
                            <tbody>
                                <tr>
                                    <th>Product ID</th>
                                    <td>
                                        <input type="text" name="upproductid" id="upproductid" value={this.state.upproductid} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Product Name</th>
                                    <td>
                                        <input name="upproductName" id="upproductName" value={this.state.upproductName} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Product Price</th>
                                    <td>
                                        <input name="upproductPrice" id="upproductPrice" value={this.state.upproductPrice} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Product Size</th>
                                    <td>
                                        <input name="upproductSize" id="upproductSize" value={this.state.upproductSize} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Product Amount</th>
                                    <td>
                                        <input name="upproductAmount" id="upproductAmount" value={this.state.upproductAmount} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                            </tbody>
                        </table><br />
                        <input type="hidden" name="upproductid" id="upproductid" onChange={this.handleUpChange} />
                        <input type="submit" value="Update Product" />
                    </form>
                </div>
            </div>
        );
    }
});

var EmployeeList = React.createClass({
    render: function () {
        var employeeNodes = this.props.data.map(function (product) {
            return (
                <Employee

                    prodid={product.productid}
                    prodName={product.productName}
                    prodPrice={product.productPrice}
                    prodSize={product.productSize}
                    prodAmount={product.productAmount}

                >
                </Employee>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeeNodes}
            </tbody>
        );
    }
});



var Employee = React.createClass({
    getInitialState: function () {
        return {
            upprodid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupempkey = this.props.empkey;
        
        this.loadSingleEmp(theupempkey);
    },
    loadSingleEmp: function (theupempkey) {
        $.ajax({
            url: '/getsingleproduct',
            data: {
                'upempkey': theupempkey
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (product) {
                    upprodid.value = product.productid;
                    upproductName.value = product.productName;
                    upproductPrice.value = product.productPrice;
                    upproductSize.value = product.productSize;
                    upproductAmount.value = product.productAmount;



                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        
    },

    render: function () {
        
        
 
        
        return (
            
            <tr>
                            <td>
                                {this.props.upproductid}
                            </td>
                            <td>
                                {this.props.upproductName}
                            </td>
                            <td>
                                {this.props.upproductPrice}
                            </td>
                            <td>
                                {this.props.upproductSize}
                </td>
                <td>
                    {this.props.upproductAmount}
                </td>
                            <td>
                            <form onSubmit={this.updateRecord}>
                                     
                                    <input type="submit" value="Update Record" />
                                </form>
                            </td>
                </tr>
        );
    }
});

var SelectList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="emptype" id="emptype">
                <option value = "0"></option>
                {optionNodes}
            </select>
        );
    }
});

var SelectUpdateList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="upemptype" id="upemptype">
                <option value="0"></option>
                {optionNodes}
            </select>
        );
    }
});


ReactDOM.render(
    <EmployeeBox />,
    document.getElementById('content')
);

