const express = require('express');
const PORT = process.env.PORT || 3000;
const app = express();
require('./routes/html-routes.js')(app)
var path = require('path');
app.use(express.static(path.join(__dirname,'html')));
app.listen(PORT, () =>{
    console.log('App is running on port ${PORT}')
});