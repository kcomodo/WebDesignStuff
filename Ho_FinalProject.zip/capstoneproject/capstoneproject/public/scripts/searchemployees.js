var EmployeesBox = React.createClass({
    getInitialState: function () {

        return { data: [] };
    },
    loadEmployeesFromServer: function () {
        $.ajax({
            url: '/getemp',
            data: {
                'employeesid': employeesid.value,
                'employeesEmail': employeesEmail.value,
                'employeesFirstName': employeesFirstName.value,
                'employeesLastName': employeesLastName.value
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
    
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {

        this.loadEmployeesFromServer();
  
  
    },

    render: function () {
        return (
            <div>
                <h1>Employees Info</h1>
                <EmployeesForm onEmployeesSubmit={this.loadEmployeesFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Key</th>
                                <th>Last Name</th>
                                <th>First Name</th>
                                <th>Email</th>
                            </tr>
                         </thead>
                        <EmployeesList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var EmployeesForm = React.createClass({
    getInitialState: function () {
        return {
            employeesid: "",
            employeesEmail: "",
            employeesFirstName: "",
            employeesLastName: "",
            data: []
        };
    },

    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the default behavior
        e.preventDefault();

        var employeesid = this.state.employeesid.trim();
        var employeesEmail = this.state.employeesEmail.trim();
        var employeesLastName = this.state.employeesLastName.trim();
        var employeesFirstName = this.state.employeesFirstName.trim();

        this.props.onEmployeesSubmit({
            employeesid: employeesid, employeesEmail: employeesEmail, employeesLastName: employeesLastName, employeesFirstName: employeesFirstName
        });


    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Employees</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Employee ID</th>
                            <td>
                                <input type="text" name="employeesid" id="employeesid" value={this.state.employeesid} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Email</th>
                            <td>
                                <input name="employeesEmail" id="employeesEmail" value={this.state.employeesEmail} onChange={this.handleChange} />
                            </td>
                        </tr> 
                        <tr>
                            <th>Employee First Name</th>
                            <td>
                                <input name="employeesFirstName" id="employeesFirstName" value={this.state.employeesFirstName} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Employee Last Name</th>
                            <td>
                                <input name="employeesLastName" id="employeesLastName" value={this.state.employeesLastName} onChange={this.handleChange} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <input type="submit" value="Search Employee" />

            </form>
        );
    }
});

var EmployeesList = React.createClass({
    render: function () {
        var employeesNodes = this.props.data.map(function (employees) {
            //map the data to individual donations
            return (
                <Employees
                    ekey={employees.employeesid}
                    eEmail={employees.employeesEmail}
                    eFirstName={employees.employeesFirstName}
                    eLastName={employees.employeesLastName}
             
                >
                </Employees>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeesNodes}
            </tbody>
        );
    }
});



var Employees = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
                            <td>
                                {this.props.ekey} 
                            </td>
                          
                            <td>
                                {this.props.empFirstName}
                            </td>
                            <td>
                                {this.props.eLastName}
                            </td>
                            <td>
                                {this.props.eEmail}
                            </td>

                </tr>
        );
    }
});


ReactDOM.render(
    <EmployeesBox />,
    document.getElementById('content')
);

