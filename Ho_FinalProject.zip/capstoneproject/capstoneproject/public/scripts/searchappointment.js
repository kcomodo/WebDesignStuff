var AppointmentBox = React.createClass({
    getInitialState: function () {
       
        return { data: [] };
    },
    loadAppointmentFromServer: function () {
        $.ajax({
            url: '/getapp',
            data: {
                'appointmentid': appointmentid.value,
                'customerFirstName': customerFirstName.value,
                'customerLastName': customerLastName.value,
                'reason': reason.value
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
               
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
   
        this.loadAppointmentFromServer();
 
    },

    render: function () {
        return (
            <div>
                <h1>Appointment Info</h1>
                <AppointmentForm onAppointmentSubmit={this.loadAppointmentFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Appointment ID</th>
                                <th>Customer First Name</th>
                                <th>Customer Last Name</th>
                                <th>Reason</th>

                         
                            </tr>
                         </thead>
                        <AppointmentList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var AppointmentForm = React.createClass({
    getInitialState: function () {
        return {
            appointmentid: "",
            customerFirstName: "",
            customerLastName: "",
            reason:"",
            data: []
        };
    },

    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the default behavior
        e.preventDefault();

        var appointmentid = this.state.appointmentid;
        var customerFirstName = this.state.customerFirstName;
        var customerLastName = this.state.customerLastName;
        var reason = this.state.reason;

 
        this.props.onAppointmentSubmit({
            appointmentid: appointmentid, customerFirstName: customerFirstName, customerLastName: customerLastName, reason: reason
        });


    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
       

        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Appointment Information</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Appointment ID</th>
                            <td>
                                <input type="text" name="appointmentid" id="appointmentid" value={this.state.appointmentid} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer First Name</th>
                            <td>
                                <input name="customerFirstName" id="customerFirstName" value={this.state.customerFirstName} onChange={this.handleChange} />
                            </td>
                        </tr> 
                        <tr>
                            <th>Customer Last Name</th>
                            <td>
                                <input name="customerLastName" id="customerLastName" value={this.state.customerLastName} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Customer Reason for appointment</th>
                            <td>
                                <input name="reason" id="reason" value={this.state.reason} onChange={this.handleChange} />
                            </td>
                        </tr>

                    </tbody>
                </table>
                <input type="submit" value="Search Appointment" />

            </form>
        );
    }
});

var AppointmentList = React.createClass({
    render: function () {
        var appointmentNodes = this.props.data.map(function (appointment) {
            //map the data to individual donations
            return (
                <Appointment
                    aid={appointment.appointmentid}
                    aCustomerFirstName={appointment.customerFirstName}
                    aCustomerLastName={appointment.customerLastName}
                    areason={appointment.reason}

      
             
                >
                </Appointment>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {appointmentNodes}
            </tbody>
        );
    }
});



var Appointment = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
                            <td>
                                {this.props.aid} 
                            </td>
                            <td>
                                {this.props.aCustomerFirstName}
                            </td>
                            <td>
                                {this.props.aCustomerLastName}
                            </td>
                            <td>
                                {this.props.areason}
                            </td>
 

                </tr>
        );
    }
});


ReactDOM.render(
    <AppointmentBox />,
    document.getElementById('content')
);

