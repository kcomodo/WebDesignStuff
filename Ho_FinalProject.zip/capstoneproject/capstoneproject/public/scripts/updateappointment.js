var ApppointmentBox = React.createClass({
    getInitialState: function () {
        return {
            data: []            
        };
    },
    loadAppointmentFromServer: function () {


        $.ajax({
            url: '/getapp',
            data: {
                'appointmentid': appointmentid.value,
                'customerFirstName': customerFirstName.value,
                'customerLastName': customerLastName.value,
                'reason':reason.value
 
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleEmpFromServer: function (appointment) {
        
        $.ajax({
            url: '/updatesingleappointment',
            dataType: 'json',
            data: appointment,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadAppointmentFromServer();
    },

    render: function () {
        return (
            <div>
                <h1>Search Appointment</h1>
                <AppointmentForm onAppointmentSubmit={this.loadAppointmentFromServer} />
                <br />
                <div id = "theresults">
                    <div id = "theleft">
                    <table>
                        <thead>
                            <tr>
                                <th>Appointment ID</th>
                                <th>Customer First Name</th>
                                <th>Customer Last Name</th>
                                <th>Customer Reason</th>

                      
                                <th></th>
                            </tr>
                        </thead>
                        <AppointmentList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <AppointmentUpdateform onUpdateSubmit={this.updateSingleEmpFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var AppointmentForm = React.createClass({
    getInitialState: function () {
        return {
            appointmentid: "",
            customerFirstName: "",
            customerLastName: "",
            reason: "",
            data: []
        };
    },
    handleOptionChange: function (e) {
        this.setState({
            selectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleSubmit: function (e) {
        e.preventDefault();

        var appointmentid = this.state.appointmentid;
        var customerFirstName = this.state.customerFirstName;
        var customerLastName = this.state.customerLastName;
        var reason = this.state.reason;

      


        this.props.onEmployeeSubmit({
            appointmentid: appointmentid, customerFirstName: customerFirstName, customerLastName: customerLastName, reason:reason
   
        });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id = "theform">
                    <form onSubmit={this.handleSubmit}>
                
                        <table>
                            <tbody>
                                <tr>
                                    <th>Appointment ID</th>
                                    <td>
                                        <input type="text" name="appointmentid" id="appointmentid" value={this.state.appointmentid} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer First Name</th>
                                    <td>
                                        <input name="customerFirstName" id="customerFirstName" value={this.state.customerFirstName} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Last Name</th>
                                    <td>
                                        <input name="customerLastName" id="customerLastName" value={this.state.customerLastName} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Reason</th>
                                    <td>
                                        <input name="reason" id="reason" value={this.state.reason} onChange={this.handleChange} />
                                    </td>
                                </tr>
           
 
                            </tbody>
                        </table><br/>
                        <input type="submit" value="Search Appointment" />
                     </form>
                </div>
                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Clear Form" />
                    </form>
                </div>
        </div>
        );
    }
});

var AppointmentUpdateform = React.createClass({
    getInitialState: function () {
        return {
   
            uappointmentid: "",
            upcustomerFirstName: "",
            upcustomerLastName: "",
            upreason: "",


            updata: []
        };
    },
    handleUpOptionChange: function (e) {
        this.setState({
            upselectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ updata: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleUpSubmit: function (e) {
        e.preventDefault();

        var upappointmentid = this.state.upappointmentid;
        var upcustomerFirstName = this.state.upcustomerFirstName;
        var upcustomerLastName = this.state.upcustomerLastName;
        var upreason = this.state.upreason;


        this.props.onUpdateSubmit({

            upappointmentid: upappointmentid, upcustomerFirstName: upcustomerFirstName, upcustomerLastName: upcustomerLastName, upreason:upreason
        });


    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id="theform">
                    <form onSubmit={this.handleUpSubmit}>

                        <table>
                            <tbody>
                                <tr>
                                    <th>Appointment ID</th>
                                    <td>
                                        <input type="text" name="upappointmentid" id="upappointmentid" value={this.state.upappointmentid} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer First Name</th>
                                    <td>
                                        <input name="upcustomerFirstName" id="upcustomerFirstName" value={this.state.upcustomerFirstName} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Last Name</th>
                                    <td>
                                        <input name="upcustomerLastName" id="upcustomerLastName" value={this.state.upcustomerLastName} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Customer Reason for appointment</th>
                                    <td>
                                        <input name="upreason" id="upreason" value={this.state.upreason} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
   
                            </tbody>
                        </table><br />
                        <input type="hidden" name="upappointmentid" id="upappointmentid" onChange={this.handleUpChange} />
                        <input type="submit" value="Update Appointment" />
                    </form>
                </div>
            </div>
        );
    }
});

var AppointmentList = React.createClass({
    render: function () {
        var appointmentNodes = this.props.data.map(function (appointment) {
            return (
                <Appointment

                    appid={appointment.appointmentid}
                    cusFirstname={appointment.customerFirstName}
                    cusLastName={appointment.customerLastName}
                    reason={appointment.reason}
                >
                </Appointment>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {appointmentNodes}
            </tbody>
        );
    }
});



var Appointment = React.createClass({
    getInitialState: function () {
        return {
            upappointmentid: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupempkey = this.props.empkey;
        
        this.loadSingleEmp(theupempkey);
    },
    loadSingleEmp: function (theupempkey) {
        $.ajax({
            url: '/getsingleappointment',
            data: {
                'upempkey': theupempkey
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (appointment) {
                    upappointmentid.value = appointment.appointmentid;
                    upcustomerFirstName.value = appointment.customerFirstName;
                    upcustomerLastName.value = appointment.customerLastName;
                    upreason.value = appointment.reason;



                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        
    },

    render: function () {
        
        
 
        
        return (
            
            <tr>
                            <td>
                                {this.props.appid}
                            </td>
                            <td>
                                {this.props.cusFirstname}
                            </td>
                            <td>
                                {this.props.cusLastName}
                            </td>
                            <td>
                                {this.props.reason}
                            </td>
  
                            <td>
                            <form onSubmit={this.updateRecord}>
                                     
                                    <input type="submit" value="Update Record" />
                                </form>
                            </td>
                </tr>
        );
    }
});

var SelectList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="emptype" id="emptype">
                <option value = "0"></option>
                {optionNodes}
            </select>
        );
    }
});

var SelectUpdateList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="upemptype" id="upemptype">
                <option value="0"></option>
                {optionNodes}
            </select>
        );
    }
});


ReactDOM.render(
    <AppointmentBox />,
    document.getElementById('content')
);

