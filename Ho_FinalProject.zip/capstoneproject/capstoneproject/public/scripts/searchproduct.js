var ProductBox = React.createClass({
    getInitialState: function () {
        //this will hold all the data being read and posted to the file
        return { data: [] };
    },
    loadProductFromServer: function () {
        $.ajax({
            url: '/getprod',
            data: {
                'productid': productid.value,
                 'productName': productName.value,
                'productPrice': productPrice.value,
                'productSize': productSize.value,
                'productAmount': productAmount.value
            },
            dataType: 'json',
            cache: false,
            success: function (data) {

                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {

        this.loadProductFromServer();

    },

    render: function () {
        return (
            <div>
                <h1>Product Info</h1>
                <ProductForm onProductSubmit={this.loadProductFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                            <th>Product Size</th>
                            <th>Product Amount</th>
                            </tr>
                         </thead>
                        <ProductList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var ProductForm = React.createClass({
    getInitialState: function () {
        return {
            productid: "",
            productName: "",
            productPrice: "",
            productSize: "",
            productAmount: ""
        };
    },

    handleSubmit: function (e) {

        e.preventDefault();

        var productid = this.state.productid;
        var productName = this.state.productName;
        var productPrice = this.state.productPrice;
        var productSize = this.state.productSize;
        var productAmount = this.state.productAmount;

        this.props.onProductSubmit({
            productid: productid, productName: productName, productPrice: productPrice, productSize: productSize, productAmount: productAmount
        });


    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Product</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Product ID</th>
                            <td>
                                <input type="text" name="productid" id="productid" value={this.state.productid} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Product Name</th>
                            <td>
                                <input name="productName" id="productName" value={this.state.productName} onChange={this.handleChange} />
                            </td>
                        </tr> 
                        <tr>
                            <th>Product Price</th>
                            <td>
                                <input name="productSize" id="productSize" value={this.state.productSize} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Product Size</th>
                            <td>
                                <input name="productPrice" id="productPrice" value={this.state.productPrice} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Product Amount</th>
                            <td>
                                <input name="productAmount" id="productAmount" value={this.state.productAmount} onChange={this.handleChange} />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <input type="submit" value="Search Product" />

            </form>
        );
    }
});

var ProductList = React.createClass({
    render: function () {
        var productNodes = this.props.data.map(function (product) {
            //map the data to individual donations
            return (
                <Product
                    pid={product.productid}
                    pName={product.productName}
                    pSize={product.productSize}
                    pPrice={product.productPrice}
                    pAmount={product.productAmount}
             
                >
                </Product>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {productNodes}
            </tbody>
        );
    }
});



var Product = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
                            <td>
                                {this.props.pid} 
                            </td>
                            <td>
                                {this.props.pName}
                            </td>
                            <td>
                                {this.props.pSize}
                            </td>
                            <td>
                                {this.props.pPrice}
                            </td>
                            <td>
                                {this.props.pAmount}
                            </td>


                </tr>
        );
    }
});


ReactDOM.render(
    <ProductBox />,
    document.getElementById('content')
);

