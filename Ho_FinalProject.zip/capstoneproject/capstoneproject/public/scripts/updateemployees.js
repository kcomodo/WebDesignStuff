var EmployeesBox = React.createClass({
    getInitialState: function () {
        return {
            data: []            
        };
    },
    loadEmployeesFromServer: function () {
        $.ajax({
            url: '/getemp',
            data: {
                'employeesid': employeesid.value,
                'employeesEmail': employeesEmail.value,
                'employeesFirstName': employeeesFirstName.value,
                'employeesLastName': employeesLastName.value
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleEmpFromServer: function (employee) {
        
        $.ajax({
            url: '/updatesingleemp',
            dataType: 'json',
            data: employee,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadEmployeesFromServer();
    },

    render: function () {
        return (
            <div>
                <h1>Search Employees</h1>
                <EmployeesForm onEmployeesSubmit={this.loadEmployeesFromServer} />
                <br />
                <div id = "theresults">
                    <div id = "theleft">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Email</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th></th>
                            </tr>
                        </thead>
                        <EmployeesList data={this.state.data} />
                        </table>
                    </div>
                    <div id="theright">
                        <EmployeesUpdateform onUpdateSubmit={this.updateSingleEmpFromServer} />
                    </div>
                </div>
            </div>
        );
    }
});

var EmployeesForm = React.createClass({
    getInitialState: function () {
        return {
            employeesid: "",
            employeesEmail: "",
            employeeesFirstName: "",
            employeesLastName: "",
            data: []
        };
    },
    handleOptionChange: function (e) {
        this.setState({
            selectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleSubmit: function (e) {
        e.preventDefault();

        var employeesid = this.state.employeesid.trim();
        var employeesEmail = this.state.employeesEmail.trim();
        var employeesFirstName = this.state.employeeFirstName.trim();
        var employeeLastName = this.state.employeephone.trim();


        this.props.onEmployeesSubmit({
            employeesid: employeesid,
            employeesEmail: employeesEmail,
            employeesFirstName: employeesFirstName,
            employeeLastName: employeeLastName
   
        });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id = "theform">
                    <form onSubmit={this.handleSubmit}>
                
                        <table>
                            <tbody>
                                <tr>
                                    <th>Employee ID</th>
                                    <td>
                                        <input type="text" name="employeesid" id="employeesid" value={this.state.employeesid} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee Email</th>
                                    <td>
                                        <input name="employeesEmail" id="employeesEmail" value={this.state.employeesEmail} onChange={this.handleChange}  />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee First Name</th>
                                    <td>
                                        <input name="employeesFirstName" id="employeesFirstName" value={this.state.employeesFirstName} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee Last Name</th>
                                    <td>
                                        <input name="employeesLastName" id="employeesLastName" value={this.state.employeesLastName} onChange={this.handleChange}  />
                                    </td>
                                </tr>
 
                            </tbody>
                        </table><br/>
                        <input type="submit" value="Search Employee" />
                     </form>
                </div>
                <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Clear Form" />
                    </form>
                </div>
        </div>
        );
    }
});

var EmployeesUpdateform = React.createClass({
    getInitialState: function () {
        return {
   
            upemployeesid: "",
            upemployeesEmail: "",
            upemployeesFirstName: "",
            upemployeesLastName: "",

            updata: []
        };
    },
    handleUpOptionChange: function (e) {
        this.setState({
            upselectedOption: e.target.value
        });
    },
    loadEmpTypes: function () {
        $.ajax({
            url: '/getemptypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ updata: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadEmpTypes();

    },
    handleUpSubmit: function (e) {
        e.preventDefault();

        var upemployeesid = upempid.value;
        var upemployeesEmail = upempEmail.value;
        var upemployeesFirstName = upempFirstName.value;
        var upemployeesLastName = upempLastName.value;


        this.props.onUpdateSubmit({

            upemployeesid: upemployeesid,
            upemployeesEmail: upemployeesEmail,
            upemployeesFirstName: upemployeesFirstName,
            upemployeesLastName: upemployeesLastName
        });


    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id="theform">
                    <form onSubmit={this.handleUpSubmit}>

                        <table>
                            <tbody>
                                <tr>
                                    <th>Employee ID</th>
                                    <td>
                                        <input type="text" name="upempid" id="upempid" value={this.state.upempid} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee Hire Date</th>
                                    <td>
                                        <input name="upempEmail" id="upempEmail" value={this.state.upempEmail} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee First Name</th>
                                    <td>
                                        <input name="upempFirstName" id="upempFirstName" value={this.state.upempFirstName} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th>Employee Last Name</th>
                                    <td>
                                        <input name="upempLastName" id="upempLastName" value={this.state.upempLastName} onChange={this.handleUpChange} />
                                    </td>
                                </tr>
                            </tbody>
                        </table><br />
                        <input type="hidden" name="upempid" id="upempid" onChange={this.handleUpChange} />
                        <input type="submit" value="Update Employee" />
                    </form>
                </div>
            </div>
        );
    }
});

var EmployeesList = React.createClass({
    render: function () {
        var employeesNodes = this.props.data.map(function (employees) {
            return (
                <Employees

                    empid={employees.employeesid}
                    empEmail={employees.employeesEmail}
                    empFirstName={employee.employeeFirstName}
                    empLastName={employee.employeesLastName}
                >
                </Employees>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {employeesNodes}
            </tbody>
        );
    }
});



var Employees = React.createClass({
    getInitialState: function () {
        return {
            upempkey: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupempkey = this.props.empkey;
        
        this.loadSingleEmp(theupempkey);
    },
    loadSingleEmp: function (theupempkey) {
        $.ajax({
            url: '/getsingleemp',
            data: {
                'upempkey': theupempkey
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateEmp = this.state.singledata.map(function (employees) {
                    upempid.value = employees.employeesid;
                    upempEmail.value = employees.employeesEmail;
                    upempFirstName.value = employees.employeesFirstName;
                    upempLastName.value = employees.employeesLastName;


                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        
    },

    render: function () {
        
        
 
        
        return (
            
            <tr>
                            <td>
                                {this.props.empid}
                            </td>
                            <td>
                                {this.props.empEmail}
                            </td>
                            <td>
                                {this.props.employeesFirstName}
                            </td>
                            <td>
                                {this.props.employeesLastName}
                            </td>
                            <td>
                            <form onSubmit={this.updateRecord}>
                                     
                                    <input type="submit" value="Update Record" />
                                </form>
                            </td>
                </tr>
        );
    }
});

var SelectList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="emptype" id="emptype">
                <option value = "0"></option>
                {optionNodes}
            </select>
        );
    }
});

var SelectUpdateList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (empTypes) {
            return (
                <option
                    key={empTypes.dbemptypeid}
                    value={empTypes.dbemptypeid}
                >
                    {empTypes.dbemptypename}
                </option>
            );
        });
        return (
            <select name="upemptype" id="upemptype">
                <option value="0"></option>
                {optionNodes}
            </select>
        );
    }
});


ReactDOM.render(
    <EmployeesBox />,
    document.getElementById('content')
);

