var CustomerBox = React.createClass({
    getInitialState: function () {

        return { data: [] };
    },
    loadCustomerFromServer: function () {
        $.ajax({
            url: this.props.url,
            dataType: 'json',
            cache: false,
            success: function (data) {
         
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
     
        this.loadCustomerFromServer();
   
     
    },
    handleCustomerSubmit: function (Customer) {

        $.ajax({
            url: '/customers',
            dataType: 'json',
            type: 'POST',
            data: Customer,
            success: function (data) {
        
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    render: function () {

        return (
            <div className="CustomerBox">


                <CustomerForm onCustomerSubmit={this.handleCustomerSubmit} />
            </div>
        );
    }
});



var CustomerForm = React.createClass({
    getInitialState: function () {
        return {

            customerid: "",
            customerFirstName: "",
            customerLastName: "",
            customerAddress1: "",
            customerAddress2: "",
            customerCity: "",
            customerState: "",
            customerZip: "",
            customerPhoneNumber: ""
        };
    },
    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the defaul behavior
        e.preventDefault();

        //we clean up the data as we save it
        var customerid = this.state.customerid;
        var customerFirstName = this.state.customerFirstName;
        var customerLastName = this.state.customerLastName;
        var customerAddress1 = this.state.customerAddress1;
        var customerAddress2 = this.state.customerAddress2;
        var customerCity = this.state.customerCity;
        var customerState = this.state.customerState;
        var customerZip = this.state.customerZip;
        var customerPhoneNumber = this.state.customerPhoneNumber;



        //these two items are required
        if (!customerid || !customerFirstName || !customerLastName || !customerAddress1 || !customerAddress2 || !customerCity || !customerState || !customerZip || !customerPhoneNumber) {
            return;
        }

        //Here we do the final submit to the parent component
        this.props.onCustomerSubmit({
            customerid: customerid, customerFirstName: customerFirstName, customerLastName: customerLastName, customerAddress1: customerAddress1, customerAddress2: customerAddress2, customerCity: customerCity,
            customerState: customerState, customerZip: customerZip, customerPhoneNumber: customerPhoneNumber
        });

        //Now that the form is submitted, we empty all the fields
        this.setState({
            customerid: '',
            customerFirstName: '',
            customerLastName: '',
            customerAddress1: '',
            customerAddress2: '',
            customerCity: '',
            customerState: '',
            customerZip: '',
            customerPhoneNumber: ''


          
        });
    },
    validateEmail: function (value) {
        // regex from http://stackoverflow.com/questions/46155/validate-email-address-in-javascript
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(value);
    },
    validateDollars: function (value) {
        //will accept dollar amounts with two digits after the decimal or no decimal
        //will also accept a number with or without a dollar sign
        var regex = /^\$?[0-9]+(\.[0-9][0-9])?$/;
        return regex.test(value);
    },
    commonValidate: function () {
        //you could do something here that does general validation for any form field
        return true;
    },
    setValue: function (field, event) {
        //If the contributor input field were directly within this
        //this component, we could use this.refs.contributor.value
        //Instead, we want to save the data for when the form is submitted
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },
    render: function () {
        //Each form field is actually another component.
        //Two of the form fields use the same component, but with different variables
        return (

            <form className="CustomerForm" onSubmit={this.handleSubmit}>
                <h1>Customer</h1>
                <h2>Insert Customer Information</h2>

                <TextInput
                    value={this.state.customerid}
                    uniqueName="customerid"
                    text="Customer ID"
                    textArea={false}
                    required={true}
                    minCharacters={2}
                    maxCharacters={45}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerid')}
                    errorMessage="Customer ID is invalid"
                    emptyMessage="Customer ID is required" />


                <TextInput
                    value={this.state.customerFirstName}
                    uniqueName="customerFirstName"
                    text="Enter Customer First Name"
                    textArea={false}
                    required={true}
                    minCharacters={1}
                    maxCharacters={45}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerFirstName')}
                    errorMessage="Customer First Name is invalid"
                    emptyMessage="Customer First Name is required" />
        
                <TextInput
                    value={this.state.customerLastName}
                    uniqueName="customerLastName"
                    text="Enter Customer Last Name"
                    textArea={false}
                    required={true}
                    minCharacters={1}
                    maxCharacters={45}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerLastName')}
                    errorMessage="Customer Last Name is invalid"
                    emptyMessage="Customer Last name is required" />
          
                <TextInput
                    value={this.state.customerAddress1}
                    uniqueName="customerAddress1"
                    text="Enter Customer Address"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={45}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerAddress1')}
                    errorMessage="Customer Address is invalid"
                    emptyMessage="Customer Address is required" />
        
                <TextInput
                    value={this.state.customerAddress2}
                    uniqueName="customerAddress2"
                    text="Enter Customer Address"
                    textArea={false}
                    required={false}
                    minCharacters={0}
                    maxCharacters={45}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerAddress2')}
                    />
        
                <TextInput
                    value={this.state.customerCity}
                    uniqueName="customerCity"
                    text="Enter Customer City"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={45}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerCity')}
                    errorMessage="Customer City is invalid"
                    emptyMessage="Customer City is required" />
        
                <TextInput
                    value={this.state.customerState}
                    uniqueName="customerState"
                    text="Enter Customer State"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={45}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerState')}
                    errorMessage="Customer State is invalid"
                    emptyMessage="Customer State is required" />
      
                <TextInput
                    value={this.state.customerZip}
                    uniqueName="customerZip"
                    text="Enter Customer Zip"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={5}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerZip')}
                    errorMessage="Customer Zip is invalid"
                    emptyMessage="Customer Zip is required" />
           
                <TextInput
                    value={this.state.customerPhoneNumber}
                    uniqueName="customerPhoneNumber"
                    text="Enter Customer Phone Number"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={10}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'customerPhoneNumber')}
                    errorMessage="Customer Phone is invalid"
                    emptyMessage="Customer Phone is required" />
               

                <input type="submit" value="Submit" />
            </form>
        );
    }
});


var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible
        });

        return (
            <div className={errorClass}>
                <span>{this.props.errorMessage}</span>
            </div>
        )
    }

});

var TextInput = React.createClass({
    getInitialState: function () {
        //most of these variables have to do with handling errors
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "Input is invalid",
            errorVisible: false
        };
    },

    handleChange: function (event) {
        //validate the field locally
        this.validation(event.target.value);

        //Call onChange method on the parent component for updating it's state
        //If saving this field for final form submission, it gets passed
        // up to the top component for sending to the server
        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },

    validation: function (value, valid) {
        //The valid variable is optional, and true if not passed in:
        if (typeof valid === 'undefined') {
            valid = true;
        }

        var message = "";
        var errorVisible = false;

        //we know how to validate text fields based on information passed through props
        if (!valid) {
            //This happens when the user leaves the field, but it is not valid
            //(we do final validation in the parent component, then pass the result
            //here for display)
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            //this happens when we have a required field with no text entered
            //in this case, we want the "emptyMessage" error message
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacters) {
            //This happens when the text entered is not the required length,
            //in which case we show the regular error message
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        //setting the state will update the display,
        //causing the error message to display if there is one.
        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });

    },

    handleBlur: function (event) {
        //Complete final validation from parent element when complete
        var valid = this.props.validate(event.target.value);
        //pass the result to the local validation element for displaying the error
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textarea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        }
    }
});



ReactDOM.render(
    <CustomerBox />,
    document.getElementById('content')
);
