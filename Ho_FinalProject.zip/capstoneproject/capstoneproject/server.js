/**
 * This file is based on Facebook's version of server.js, included in the
 * download for this tutorial: https://facebook.github.io/react/docs/tutorial.html
 */

var fs = require('fs');
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();


const mysql = require('mysql2');
const con = mysql.createConnection({
    host: "istwebclass.org",
    user: "qho_user1",
    password:"Rzkkpur2",
    database: "qho_landscapingcompany"
});

con.connect(function (err) {

    if (err) throw (err);
    console.log("Connected");
});

app.set('port', (process.env.PORT || 3000));

app.use('/', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));



/*
app.post('/product', function (req, res) {
    var pname = req.body.productName;
    var pqty = req.body.productQty;
    var pdescr = req.body.productDescr;

    console.log(pname);
    console.log(pqty);
    console.log(pdescr);

    var sqlins = "INSERT INTO theproducts(productName, productQty, productDescr) " + 
    " VALUES (?, ?, ?)";

    var inserts = [pname, pqty, pdescr]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertproducts.html');
        res.end();
    });

});
*/
app.post('/updatesingleemp', function (req, res,) {

    var eid = req.body.upemployeesid;
    var eEmail = req.body.upemployeesEmail;
    var eFirstName = req.body.upemployeesFirstName;
    var eLastName = req.body.upemployeesLastName;


    var sqlins = "UPDATE employees SET employeesid = ?, employeesFirstName = ?, " +
        " employeesLastName = ?, employeesEmail = ? ";
    var inserts = [eid, eFirstName, eLastName, eEmail];

    var sql = mysql.format(sqlins, inserts);
    console.log(sql);
    con.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");

        res.end();
    });
});    
app.post('/updatesinglecus', function (req, res,) {

    var cid = req.body.upcustomerid;
    var cFirstName = req.body.upcustomerFirstName;
    var cLastName = req.body.upcustomerLastName;
    var cAddress1 = req.body.upcustomerAddress1;
    var cAddress2 = req.body.upcustomerAddress1;
    var cCity = req.body.upcustomerCity;
    var cState = req.body.upcustomerState;
    var cZip = req.body.upcustomerZip;
    var cPhoneNumber = req.body.upcustomerPhoneNumber;





    var sqlins = "UPDATE customerinfo SET customerid = ?, customerFirstName = ?, customerLastName = ?, " +
        " customerAddress1 = ?, customerAddress2 = ?, customerCity = ?, customerState = ?, customerZip = ?, customerPhoneNumber = ? ";
    var inserts = [cid, cFirstName, cLastName, cAddress1, cAddress2, cCity, cState, cZip, cPhoneNumber];

    var sql = mysql.format(sqlins, inserts);
    console.log(sql);
    con.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");

        res.end();
    });
}); 
app.post('/updatesingleproduct', function (req, res,) {

    var pid = req.body.upproductid;
    var pName = req.body.upproductName;
    var pPrice = req.body.upproductPrice;
    var pSize = req.body.upproductSize;
    var pAmount = req.body.upproductAmount;



    var sqlins = "UPDATE producttable SET productid = ?, productName = ?, productPrice = ?, " +
        " productSize = ?, productAmount ";
    var inserts = [pid, pName, pPrice, pSize, pAmount];

    var sql = mysql.format(sqlins, inserts);
    console.log(sql);
    con.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");

        res.end();
    });
}); 
app.post('/updatesingleappointment', function (req, res,) {

    var uid = req.body.upappointmentid;
    var uFirstName = req.body.upcustomerFirstName;
    var uLastName = req.body.upcustomerLastName;
    var ureason = req.body.upreason;



    var sqlins = "UPDATE setAppointment SET appointmentid = ?, customerFirstName = ?, customerLastName = ?, reason = ?" +
        " time = ? ";
    var inserts = [uid, uFirstName, uLastName, ureason];

    var sql = mysql.format(sqlins, inserts);
    console.log(sql);
    con.execute(sql, function (err, result) {
        if (err) throw err;
        console.log("1 record updated");

        res.end();
    });
}); 
app.get('/getapp/', function (req, res) {
    var gid = req.query.appointmentid;
    var gcustomerFirstName = req.body.customerFirstName;
    var gcustomerLastName = req.body.customerLastName;
    var greason = req.body.reason;
    console.log(gid);
    console.log(gcustomerFirstName);
    console.log(gcustomerLastName);
    console.log(greason);



    var sqlsel = 'Select * from setAppointment where appointmentid Like ? and customerFirstName Like ? and customerLastName Like ? and reason Like ?';
    var inserts = [gid, gcustomerFirstName, gcustomerLastName, greason];

    var sql = mysql.format(sqlsel, inserts);
    console.log(sql);
    con.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }

        res.send(JSON.stringify(data));
    });
});
app.get('/getemp/', function (req, res) {
    var eid = req.query.employeesid;
    var eFirstName = req.body.employeesFirstName;
    var eLastName = req.body.employeesLastName;
    var eEmail = req.body.employeesEmail;
    console.log(eid);
    console.log(eFirstName);
    console.log(eLastName);
    console.log(eEmail);

    var sqlsel = 'Select * from employees where employeesid Like ? and employeesFirstName Like ? and employeesLastName Like ? and employeesEmail Like ?';
    var inserts = [eid, eFirstName, eLastName, eEmail];

    var sql = mysql.format(sqlsel, inserts);
    console.log(sql);
    con.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }

        res.send(JSON.stringify(data));
    });
});
app.get('/getprod/', function (req, res) {
    var pid = req.query.productid;
    var pName = req.body.productName;
    var pPrice = req.body.productPrice;
    var pSize = req.body.productSize;
    var pAmount = req.body.productAmount;

    console.log(pid);
    console.log(pName);
    console.log(pPrice);
    console.log(pAmount);


    var sqlsel = 'Select * from producttable where productid Like ? and productName Like ? and productPrice Like ? and productSize Like ? and productAmount Like ?';
    var inserts = [pid, pName, pPrice, pSize, pAmount];

    var sql = mysql.format(sqlsel, inserts);
    console.log(sql);
    con.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }

        res.send(JSON.stringify(data));
    });
});
app.get('/getcust/', function (req, res) {
    var cid = req.query.employeesid;
    var cFirstName = req.body.employeesFirstName;
    var cLastName = req.body.employeesLastName;
    var cAddress1 = req.body.employeesHireDate;
    var cAddress2 = req.body.employeesHireDate;
    var cCity = req.body.employeesHireDate;
    var cState = req.body.employeesHireDate;
    var cZip = req.body.employeesHireDate;
    var cPhoneNumber = req.body.employeesHireDate;
    console.log(cid);
    console.log(cFirstName);
    console.log(cLastName);
    console.log(cAddress1);
    console.log(cAddress2);
    console.log(cCity);
    console.log(cState);
    console.log(cZip);
    console.log(cPhoneNumber);




    var sqlsel = 'Select * from customerinfo where customerid Like ? and customerFirstName Like ? and customerLastName Like ? and customerAddress1 Like ? and customerAddress2 Like ? and customerCity Like ? and customerState Like ? and customerZip Like ? and customerPhoneNumber Like ?';
    var inserts = [cid, cFirstName, cLastName, cAddress1, cAddress2,  cCity, cState, cZip,cPhoneNumber];

    var sql = mysql.format(sqlsel, inserts);
    console.log(sql);
    con.query(sql, function (err, data) {
        if (err) {
            console.error(err);
            process.exit(1);
        }

        res.send(JSON.stringify(data));
    });
});
app.post('/employees', function (req, res) {
  
    var eid = req.body.employeesid;
    var eEmail = req.body.employeesEmail;
    var eFirstName = req.body.employeesFirstName;
    var eLastName = req.body.employeesLastName;

    console.log(eid);
    console.log(eEmail);
    console.log(eFirstName);
    console.log(eLastName);

    var sqlins = "INSERT INTO employees(employeesid, employeesFirstName, employeesLastName, employeesEmail) " +
        " VALUES (?, ?, ?, ?)";

    var inserts = [eid, eFirstName, eLastName, eEmail]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertemployees.html');
        res.end();
    });

});
app.post('/orders', function (req, res) {

    var oid = req.body.oid;
    var oName = req.body.productName;
    var oQty = req.body.productQty;
    var oDate = req.body.orderDate;

    console.log(oid);
    console.log(oName);
    console.log(oQty);
    console.log(oDate);

    var sqlins = "INSERT INTO orders(orderid, productName, productQty, orderDate) " +
        " VALUES (?, ?, ?, ?)";

    var inserts = [oid, oName, oQty, oDate]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('userorder.html');
        res.end();
    });

});
app.post('/products', function (req, res) {

    var pid = req.body.productid;
    var pName = req.body.productName;
    var pPrice = req.body.productPrice;
    var pSize = req.body.productSize;
    var pAmount = req.body.productAmount;


    console.log(pid);
    console.log(pName);
    console.log(pPrice);
    console.log(pSize);
    console.log(pAmount);

    var sqlins = "INSERT INTO producttable(productid, productName, productPrice, productSize, productAmount) " +
        " VALUES (?, ?, ?, ?, ?)";

    var inserts = [pid, pName, pPrice, pSize, pAmount]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertproduct.html');
        res.end();
    });

});
app.post('/customers', function (req, res) {

    var cid = req.body.customerid;
    var cFirstName = req.body.customerFirstName;
    var cLastName = req.body.customerLastName;
    var cAddress1 = req.body.customerAddress1;
    var cAddress2 = req.body.customerAddress2;
    var cCity = req.body.customerCity;
    var cState = req.body.customerState;
    var cZip = req.body.customerZip;
    var cPhoneNumber = req.body.customerPhoneNumber;


    console.log(cid);
    console.log(cFirstName);
    console.log(cLastName);
    console.log(cAddress1);
    console.log(cAddress2);
    console.log(cCity);
    console.log(cState);
    console.log(cZip);
    console.log(cPhoneNumber);

    var sqlins = "INSERT INTO customerinfo(customerid, customerFirstName, customerLastName, customerAddress1, customerAddress2, customerCity, customerState, customerZip, customerPhoneNumber) " +
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    var inserts = [cid, cFirstName, cLastName, cAddress1, cAddress2, cCity, cState, cZip, cPhoneNumber]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertcustomer.html');
        res.end();
    });

});
app.post('/appointment', function (req, res) {

    var aid = req.body.appointmentid;
    var acustomerFirstName = req.body.customerFirstName;
    var acustomerLastName = req.body.customerLastName;
    var areason = req.body.reason;



    console.log(aid);
    console.log(acustomerFirstName);
    console.log(acustomerLastName);
    console.log(reason);



    var sqlins = "INSERT INTO setAppointment(appointmentid, customerFirstName, customerLastName, reason) " +
        " VALUES (?, ?, ?, ?)";

    var inserts = [aid, acustomerFirstName, acustomerLastName, areason]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertappointment.html');
        res.end();
    });

});
app.listen(app.get('port'), function() {
  console.log('Server started: http://localhost:' + app.get('port') + '/');
});
