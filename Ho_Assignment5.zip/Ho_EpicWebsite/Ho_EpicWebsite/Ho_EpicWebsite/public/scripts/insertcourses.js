 var FacultyBox = React.createClass({
    getInitialState: function () {
        //this will hold all the data being read and posted to the file
        return { data: [] };
    },
    loadFacultyFromServer: function () {
        $.ajax({
            url: this.props.url,
            dataType: 'json',
            cache: false,
            success: function (data) {
                //set the state with the newly loaded data so the display will update
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        //Once the component is fully loaded, we grab the employees
        this.loadFacultyFromServer();
        //... and set an interval to continuously load new data:
        setInterval(this.loadFacultyFromServer, this.props.pollInterval);
    },
    handleFacultySubmit: function (Faculty) {
        //this is just an example of how you would submit a form
        //you would have to implement something separately on the server
        $.ajax({
            url:'/courses',
            dataType: 'json',
            type: 'POST',
            data: Faculty,
            success: function (data) {
                //We set the state again after submission, to update with the submitted data
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    render: function () {
        //we list Facultys, then show the form for new Facultys
        return (
            <div className="FacultyBox">
              
                
                <FacultyForm onFacultySubmit={this.handleFacultySubmit} />
            </div>
        );
    }
});



var FacultyForm = React.createClass({
    getInitialState: function () {
        return {
            facultySelect: "",
            semesterSelect: "",
            yearSelect: "",
            coursePrefix: "",
            courseNumber: "",
            courseSection: ""

        };
    },
    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the defaul behavior
        e.preventDefault();

        //we clean up the data as we save it
        var facultySelect = this.state.facultySelect.trim();
        var semesterSelect = this.state.semesterSelect;
        var yearSelect = this.state.yearSelect;
        var coursePrefix = this.state.coursePrefix;
        var courseNumber = this.state.courseNumber;
        var courseSection = this.state.courseSection;

        //these two items are required
        if (!facultySelect || !semesterSelect) {
            return;
        }

        //Here we do the final submit to the parent component
        this.props.onFacultySubmit({
            facultySelect: facultySelect, semesterSelect: semesterSelect, yearSelect: yearSelect, coursePrefix: coursePrefix,
            courseNumber: courseNumber, courseSection: courseSection
        });

        //Now that the form is submitted, we empty all the fields
        this.setState({
            facultySelect:'',
            semesterSelect: '',
            yearSelect: '',
            coursePrefix: '',
            courseNumber: '',
            courseSection: ''
        });
    },
    validateEmail: function (value) {
        // regex from http://stackoverflow.com/questions/46155/validate-email-address-in-javascript
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(value);
    },
    validateDollars: function (value) {
        //will accept dollar amounts with two digits after the decimal or no decimal
        //will also accept a number with or without a dollar sign
        var regex = /^\$?[0-9]+(\.[0-9][0-9])?$/;
        return regex.test(value);
    },
    commonValidate: function () {
        //you could do something here that does general validation for any form field
        return true;
    },
    setValue: function (field, event) {
        //If the contributor input field were directly within this
        //this component, we could use this.refs.contributor.value
        //Instead, we want to save the data for when the form is submitted
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },
    render: function () {
        //Each form field is actually another component.
        //Two of the form fields use the same component, but with different variables
        return (
            <form className="FacultyForm" onSubmit={this.handleSubmit}>
                <h2>Insert Courses</h2>

                <TextInput
                    value={this.state.facultySelect}
                    uniqueName="facultySelect"
                    text="Faculty (Admin/Student)"
                    textArea={false}
                    required={true}
                    minCharacters={2}
                    maxCharacters={11}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'facultySelect')}
                    errorMessage="Faculty is invalid"
                    emptyMessage="Faculty is required" />
                <br /><br />

                <TextInput
                    value={this.state.semesterSelect}
                    uniqueName="semesterSelect"
                    text="Enter semester"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={6}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'semesterSelect')}
                    errorMessage="Semester is invalid"
                    emptyMessage="Semester is required" />
                <br /><br />
                <TextInput
                    value={this.state.yearSelect}
                    uniqueName="yearSelect"
                    text="Enter year"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={4}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'yearSelect')}
                    errorMessage="Year is invalid"
                    emptyMessage="Year is required" />
                <br /><br />
                <TextInput
                    value={this.state.coursePrefix}
                    uniqueName="coursePrefix"
                    text="Enter course prefix"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={3}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'coursePrefix')}
                    errorMessage="Course Prefix is invalid"
                    emptyMessage="Course Prefix is required" />
                <br /><br />
                <TextInput
                    value={this.state.courseNumber}
                    uniqueName="courseNumber"
                    text="Enter course number"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={3}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'courseNumber')}
                    errorMessage="Course number is invalid"
                    emptyMessage="Course number is required" />
                <br /><br />
                <TextInput
                    value={this.state.courseSection}
                    uniqueName="courseSection"
                    text="Enter course section"
                    textArea={false}
                    required={true}
                    minCharacters={0}
                    maxCharacters={3}
                    validate={this.commonValidate}
                    onChange={this.setValue.bind(this, 'courseSection')}
                    errorMessage="Course section is invalid"
                    emptyMessage="Course section is required" />
                <br /><br />
          


                <input type="submit" value="Submit" />
            </form>
        );
    }
});

/*
  This is a small error component that is displayed inline
  within every form field component
*/
var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = classNames(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible
        });

        return (
            <div className={errorClass}>
                <span>{this.props.errorMessage}</span>
            </div>
        )
    }

});

var TextInput = React.createClass({
    getInitialState: function () {
        //most of these variables have to do with handling errors
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "Input is invalid",
            errorVisible: false
        };
    },

    handleChange: function (event) {
        //validate the field locally
        this.validation(event.target.value);

        //Call onChange method on the parent component for updating it's state
        //If saving this field for final form submission, it gets passed
        // up to the top component for sending to the server
        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },

    validation: function (value, valid) {
        //The valid variable is optional, and true if not passed in:
        if (typeof valid === 'undefined') {
            valid = true;
        }

        var message = "";
        var errorVisible = false;

        //we know how to validate text fields based on information passed through props
        if (!valid) {
            //This happens when the user leaves the field, but it is not valid
            //(we do final validation in the parent component, then pass the result
            //here for display)
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            //this happens when we have a required field with no text entered
            //in this case, we want the "emptyMessage" error message
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacters) {
            //This happens when the text entered is not the required length,
            //in which case we show the regular error message
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }

        //setting the state will update the display,
        //causing the error message to display if there is one.
        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });

    },

    handleBlur: function (event) {
        //Complete final validation from parent element when complete
        var valid = this.props.validate(event.target.value);
        //pass the result to the local validation element for displaying the error
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textarea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />

                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        }
    }
});



ReactDOM.render(
    <FacultyBox />,
    document.getElementById('content')
);
