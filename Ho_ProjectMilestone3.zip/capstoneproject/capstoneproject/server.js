/**
 * This file is based on Facebook's version of server.js, included in the
 * download for this tutorial: https://facebook.github.io/react/docs/tutorial.html
 */

var fs = require('fs');
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();


const mysql = require('mysql2');
const con = mysql.createConnection({
    host: "istwebclass.org",
    user: "qho_user1",
    password:"Rzkkpur2",
    database: "qho_landscapingcompany"
});

con.connect(function (err) {

    if (err) throw (err);
    console.log("Connected");
});

app.set('port', (process.env.PORT || 3000));

app.use('/', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.get('/api/donations', function(req, res) {
  fs.readFile(DONATIONS_FILE, function(err, data) {
    if (err) {
      console.error(err);
      process.exit(1);
    }
    res.setHeader('Cache-Control', 'no-cache');
    res.json(JSON.parse(data));
  });
});

app.post('/api/donations', function(req, res) {
  fs.readFile(DONATIONS_FILE, function(err, data) {
    if (err) {
      console.error(err);
      process.exit(1);
    }
    var donations = JSON.parse(data);
    // NOTE: In a real implementation, we would likely rely on a database or
    // some other approach (e.g. UUIDs) to ensure a globally unique id. We'll
    // treat Date.now() as unique-enough for our purposes.
    var newDonation = {
      id: Date.now(),
      contributor: req.body.contributor,
      amount: req.body.amount,
      comment: req.body.comment
    };
    donations.push(newDonation);
    fs.writeFile(DONATIONS_FILE, JSON.stringify(donations, null, 4), function(err) {
      if (err) {
        console.error(err);
        process.exit(1);
      }
      res.setHeader('Cache-Control', 'no-cache');
      res.json(donations);
    });
  });
});

/*
app.post('/product', function (req, res) {
    var pname = req.body.productName;
    var pqty = req.body.productQty;
    var pdescr = req.body.productDescr;

    console.log(pname);
    console.log(pqty);
    console.log(pdescr);

    var sqlins = "INSERT INTO theproducts(productName, productQty, productDescr) " + 
    " VALUES (?, ?, ?)";

    var inserts = [pname, pqty, pdescr]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertproducts.html');
        res.end();
    });

});
*/
app.post('/employees', function (req, res) {
  
    var eid = req.body.employeesid;
    var eHireDate = req.body.employeesHireDate;
    var eFirstName = req.body.employeesFirstName;
    var eLastName = req.body.employeesLastName;

    console.log(eid);
    console.log(eHireDate);
    console.log(eFirstName);
    console.log(eLastName);

    var sqlins = "INSERT INTO employees(employeesid, employeesHireDate, employeesFirstName, employeesLastName) " +
        " VALUES (?, ?, ?, ?)";

    var inserts = [eid, eHireDate, eFirstName, eLastName]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertemployees.html');
        res.end();
    });

});
app.post('/products', function (req, res) {

    var pid = req.body.productid;
    var pName = req.body.productName;
    var pPrice = req.body.productPrice;
    var pSize = req.body.productSize;
    var pAmount = req.body.productAmount;


    console.log(pid);
    console.log(pName);
    console.log(pPrice);
    console.log(pSize);
    console.log(pAmount);

    var sqlins = "INSERT INTO producttable(productid, productName, productPrice, productSize, productAmount) " +
        " VALUES (?, ?, ?, ?, ?)";

    var inserts = [pid, pName, pPrice, pSize, pAmount]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertproduct.html');
        res.end();
    });

});
app.post('/customers', function (req, res) {

    var cid = req.body.customerid;
    var cFirstName = req.body.customerFirstName;
    var cLastName = req.body.customerLastName;
    var cAddress1 = req.body.customerAddress1;
    var cAddress2 = req.body.customerAddress2;
    var cCity = req.body.customerCity;
    var cState = req.body.customerState;
    var cZip = req.body.customerZip;
    var cPhoneNumber = req.body.customerPhoneNumber;


    console.log(cid);
    console.log(cFirstName);
    console.log(cLastName);
    console.log(cAddress1);
    console.log(cAddress2);
    console.log(cCity);
    console.log(cState);
    console.log(cZip);
    console.log(cPhoneNumber);

    var sqlins = "INSERT INTO customerinfo(customerid, customerFirstName, customerLastName, customerAddress1, customerAddress2, customerCity, customerState, customerZip, customerPhoneNumber) " +
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    var inserts = [cid, cFirstName, cLastName, cAddress1, cAddress2, cCity, cState, cZip, cPhoneNumber]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertcustomer.html');
        res.end();
    });

});
app.post('/appointment', function (req, res) {

    var aid = req.body.appointmentid;
    var acustomerid = req.body.customerid;
    var ainstallerid = req.body.installerid;
    var aemployeesid = req.body.employeesid;

    console.log(aid);
    console.log(acustomerid);
    console.log(ainstallerid);
    console.log(aemployeesid);

    var sqlins = "INSERT INTO appointment(appointmentid, customerid, installerid, employeesid) " +
        " VALUES (?, ?, ?, ?)";

    var inserts = [aid, acustomerid, ainstallerid, aemployeesid]

    var sql = mysql.format(sqlins, inserts);

    con.execute(sql, function (err, result) {
        if (err) throw (err);
        console.log("Success!!! 1 record inserted");
        res.redirect('insertemployees.html');
        res.end();
    });

});
app.listen(app.get('port'), function() {
  console.log('Server started: http://localhost:' + app.get('port') + '/');
});
