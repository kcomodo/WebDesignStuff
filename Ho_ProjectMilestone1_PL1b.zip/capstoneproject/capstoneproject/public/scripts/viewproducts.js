var ProductBox = React.createClass({
  getInitialState: function() {
    //this will hold all the data being read and posted to the file
    return {data: []};
  },
  loadProductsFromServer: function() {
    $.ajax({
      url: this.props.url,
      dataType: 'json',
      cache: false,
      success: function(data) {
        //set the state with the newly loaded data so the display will update
        this.setState({data: data});
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(this.props.url, status, err.toString());
      }.bind(this)
    });
  },
  componentDidMount: function() {
    //Once the component is fully loaded, we grab the Products
    this.loadProductsFromServer();
    //... and set an interval to continuously load new data:
    setInterval(this.loadProductsFromServer, this.props.pollInterval);
  },
  handleProductSubmit: function(Product) {
    //this is just an example of how you would submit a form
    //you would have to implement something separately on the server
    $.ajax({
      url: this.props.url,
      dataType: 'json',
      type: 'POST',
      data: Product,
      success: function(data) {
        //We set the state again after submission, to update with the submitted data
        this.setState({data: data});
      }.bind(this),
      error: function(xhr, status, err) {
        console.error(this.props.url, status, err.toString());
      }.bind(this)
    });
  },
  render: function() {
    //we list Products, then show the form for new Products
    return (
      <div className="ProductBox">
        <h1>Products</h1>
        <ProductList data={this.state.data} />
   
      </div>
    );
  }
});

var ProductList = React.createClass({
  render: function() {
    var ProductNodes = this.props.data.map(function(productInfo) {
      //map the data to individual Products
      return (
        <Product
          productName={productInfo  .productName}
          key={productInfo.id}
          productQty={productInfo.productQty}
        >
          {product.productDescr}
        </Product>
      );
    });
    //print all the nodes in the list
    return (
      <div className="ProductList">
        {ProductNodes}
      </div>
    );
  }
});

var Product = React.createClass({
  render: function() {
    //display an individual Product
    return (
      <div className="Product">
        <h2 className="ProductName">
          {this.props.productName}: ${this.props.productQty}
        </h2>
          {this.props.children.toString()}
      </div>
    );
  }
});



ReactDOM.render(
  <ProductBox url="/api/products" pollInterval={2000} />,
  document.getElementById('content')
);
