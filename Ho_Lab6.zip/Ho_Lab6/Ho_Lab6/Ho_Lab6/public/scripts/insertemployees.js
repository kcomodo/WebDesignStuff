var employeeBox = React.createClass({
    render: function () {
        return (
            <div className="EmployeeBox">
                <h1> Employees </h1>
                <Employeeform2 />
                </div>
            );
    }
});
var Employeeform2 = React.createClass({
    getInitialState: function () {
        return {
            employeeid: "",
            employeename: "",
            employeesalary = "",
            employeephone: "",
            employeeemail: ""
        };
    },
    validateEmail: function (value) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return regex.test(value);
    },
    validateDollars: function (value) {
        var regex = /^\$?[0-9]+(\.[0-9][0-9])?$/;
        return regex.test(value);
    },
    commonValidate: function () {
        return true;
    },
    setValue: function (field, event) {
        var object = {};
        object[field] = event.target.value;
        this.setState(object);
    },
    render: function () {
        return function () {
            return (
                <form className="employeeForm" onSubmit={this.handleSubmit}>
                    <h2>Employees</h2>
                    <table>
                        <tbody>
                            <tr>
                                <th>Employee Id</th>
                                <td>
                                    <TextInput
                                        value={this.state.employeeid}
                                        uniqueName="employeeid"
                                        textArea={false}
                                        required={true}
                                        minCharacter={6}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'employeeid')}
                                        errorMessage="Employee id is invalid "
                                        emptyMessage="Employee id is required" />
                                </td>
                            </tr>
                            <tr>
                                <th>Employee Name </th>
                                <td>
                                    <TextInput
                                        value={this.state.employeename}
                                        uniqueName="employeename"
                                        textArea={false}
                                        required={false}
                                        minCharacter={6}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'employeename')}
                                        errorMessage="Employee name is invalid "
                                        emptyMessage="Employee name is required" />
                                </td>
                            </tr>
                            <tr>
                                <th>Employee Salary</th>
                                <td>
                                    <TextInput
                                        value={this.state.employeephone}
                                        uniqueName="employeephone"
                                        textArea={false}
                                        required={true}
                                        validate={this.commonValidate}
                                        onChange={this.setValue.bind(this, 'employeephone')}
                                        errorMessage="Employee phone is invalid"
                                        emptyMessage="Employee phone is required" />
                                </td>
                            </tr>
                            <tr>
                                <th> Employee E-Mail</th>
                                <td>
                                    <TextInput
                                        value={this.state.customeremail}
                                        uniqueName="employeeemail"
                                        textArea={false}
                                        required={true}
                                        validate={this.validateEmail}
                                        onChange={this.setValue.bind(this, 'employeeemail')}
                                        errorMessage="Invalid E-Mail Address"
                                        emptyMessage="E-Mail address is required" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            );
        }
    });
var InputError = React.createClass({
    getInitialState: function () {
        return {
            message: 'Input is invalid'
        };
    },
    render: function () {
        var errorClass = className(this.props.className, {
            'error_container': true,
            'visible': this.props.visible,
            'invisible': !this.props.visible

        });
        return (
            <td> {this.props.errorMessage} </td>
        )
    }
});
var TextInput = React.createClass({
    getInitialState: function () {
        return {
            isEmpty: true,
            value: null,
            valid: false,
            errorMessage: "",
            errorVisible: false
        };
    },
    handleChange: function (event) {
        this.validation(event.target.value);
        if (this.props.onChange) {
            this.props.onChange(event);
        }
    },
    validation: function (value, valid) {
        if (typeof valid === "undefined") {
            valid = true;
        }
        var message = "";
        var errorVisible = false;
        if (!valid) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;

        }
        else if (this.props.required && jQuery.isEmptyObject(value)) {
            message = this.props.emptyMessage;
            valid = false;
            errorVisible = true;
        }
        else if (value.length < this.props.minCharacter) {
            message = this.props.errorMessage;
            valid = false;
            errorVisible = true;
        }
        this.setState({
            value: value,
            isEmpty: jQuery.isEmptyObject(value),
            valid: valid,
            errorMessage: message,
            errorVisible: errorVisible
        });
    },
    handleBlur: function (event) {
        var valid = this.props.validate(event.target.value);
        this.validation(event.target.value, valid);
    },
    render: function () {
        if (this.props.textArea) {
            return (
                <div className={this.props.uniqueName}>
                    <textArea
                        placeholder={this.props.text}
                        className={'input input-' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />
                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage} />
                </div>
            );
        } else {
            return (
                <div className={this.props.uniqueName}>
                    <input 
                        placeholder={this.props.text}
                        className={'input input- ' + this.props.uniqueName}
                        onChange={this.handleChange}
                        onBlur={this.handleBlur}
                        value={this.props.value} />
                    <InputError
                        visible={this.state.errorVisible}
                        errorMessage={this.state.errorMessage}
                    />
                    </div>
                )
        }
    }
})
ReactDOM.render(
    <employeeBox />,
    document.getElementById('content')
);
