var FacultyBox = React.createClass({
    getInitialState: function () {
        //this will hold all the data being read and posted to the file
        return { data: [] };
    },
    loadFacultyFromServer: function () {
        $.ajax({
            url: '/getemp',
            data: {
                'facultySelect': facultySelect.value,
                'semesterSelect': semesterSelect.value,
                'yearSelect': yearSelect.value,
                'coursePrefix': coursePrefix.value,
                'courseNumber': courseNumber.value,
                'courseSection':courseSection.value

            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                //set the state with the newly loaded data so the display will update
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    componentDidMount: function () {
        //Once the component is fully loaded, we grab the donations
        this.loadFacultyFromServer();
        //... and set an interval to continuously load new data:
        setInterval(this.loadloadFacultyFromServer, this.props.pollInterval);
    },

    render: function () {
        return (
            <div>
                <h1>Courses</h1>
                <Facultyform2 onFacultySubmit={this.loadFacultyFromServer} />
                <br />
                <table>
                        <thead>
                            <tr>
                                <th>Faculty</th>
                                <th>Semester</th>
                                <th>Year</th>
                                <th>Course Prefix</th>
                                <th>Course Number</th>
                                 <th>Course Section</th>
                            </tr>
                         </thead>
                        <FacultyList data={this.state.data} />
                    </table>
                
            </div>
        );
    }
});

var Facultyform2 = React.createClass({
    getInitialState: function () {
        return {
            facultySelect: "",
            semesterSelect: "",
            yearSelect: "",
            coursePrefix: "",
            courseNumber: "",
            courseSection: ""
        };
    },

    handleSubmit: function (e) {
        //we don't want the form to submit, so we prevent the default behavior
        e.preventDefault();

        var facultySelect = this.state.facultySelect.trim();
        var semesterSelect = this.state.semesterSelect;
        var yearSelect = this.state.yearSelect;
        var coursePrefix = this.state.coursePrefix;
        var courseNumber = this.state.courseNumber;
        var courseSection = this.state.courseSection;
    
        if (!facultySelect || !semesterSelect) {
            return;
        }

        this.props.onFacultySubmit({
            facultySelect: facultySelect, semesterSelect: semesterSelect, yearSelect: yearSelect, coursePrefix: coursePrefix,
            courseNumber: courseNumber, courseSection: courseSection
        });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <form onSubmit={this.handleSubmit}>
                <h2>Search Courses</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Faculty</th>
                            <td>
                                <input type="text" name="facultySelect" id="facultySelect" value={this.state.facultySelect} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Semester</th>
                            <td>
                                <input type="text" name="semesterSelect" id="semesterSelect" value={this.state.semesterSelect} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Year</th>
                            <td>
                                <input type="text" name="yearSelect" id="yearSelect" value={this.state.yearSelect} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Course Prefix</th>
                            <td>
                                <input type="text" name="coursePrefix" id="coursePrefix" value={this.state.coursePrefix} onChange={this.handleChange}/>
                            </td>
                        </tr>
                        <tr>
                            <th>Course Number</th>
                            <td>
                                <input type="text" name="courseNumber" id="courseNumber" value={this.state.courseNumber} onChange={this.handleChange}/>
                            </td>
                        </tr>    
                        <tr>
                            <th>CourseSection</th>
                            <td>
                                <input type="text" name="courseSection" id="courseSection" value={this.state.courseSection} onChange={this.handleChange}/>
                            </td>
                        </tr>    
                    </tbody>
                </table>
                <input type="submit" value="Search Courses" />

            </form>
        );
    }
});

var FacultyList = React.createClass({
    render: function () {
        var facultyNodes = this.props.data.map(function (faculty) {
            //map the data to individual donations
            return (
                <Faculty
      
             
                    empfaculty={faculty.facultySelect}
                    empsemester={faculty.semesterSelect}
                    empyear={faculty.yearSelect}
                    empCPrefix={faculty.coursePrefix}
                    empCNumber={faculty.courseNumber}
                    empCSection={faculty.courseSection}
                >
                </Faculty>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {facultyNodes}
            </tbody>
        );
    }
});



var Faculty = React.createClass({

    render: function () {
        //display an individual donation
        return (

            <tr>
      
                            <td>
                                {this.props.empfaculty}
                            </td>
                            <td>
                                {this.props.empsemester}
                            </td>
                            <td>
                                {this.props.empyear}
                            </td>
                            <td>
                                {this.props.empCPrefix}
                            </td>
                            <td>
                                {this.props.empCNumber}
                             </td>
                            <td>
                                {this.props.empCSection}
                            </td>

                </tr>
        );
    }
});


ReactDOM.render(
    <FacultyBox />,
    document.getElementById('content')
);

